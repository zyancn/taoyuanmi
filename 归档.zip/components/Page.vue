<template>
	<view class="bottomPage" v-if="length > 0">
		<view class="bottomPage-box" @click="turnPage(page-1)">
			<cl-icon name="cl-icon-arrow-left" :size="size" class="bottomPage-box-font" :class="{'active' : page > 1}"></cl-icon>
		</view>
		<view class="bottomPage-box">{{page}}</view>
		<view class="bottomPage-box" @click="turnPage(page+1)">
			<cl-icon name="cl-icon-arrow-right" :size="size" class="bottomPage-box-font" :class="{'active' : length >= max}"></cl-icon>
		</view>
	</view>
	</view>
</template>

<script>
export default {
	props: {
		length:{
			type: Number,
			default: 0
		},
		max:{
			type: Number,
			default: 10
		},
		size:{
			type: Number,
			default: 20
		}
	},
	data() {
		return {
            page: 1
		};
	},
	watch: {
    
	},
	methods: {
		turnPage(page){
			if(page < 1){
				return
			}
			if(page > this.page && this.length < this.max){
				return
			}
			this.page = page
			this.$emit('change', this.page);
		}
	}
};
</script>

<style lang="scss" scoped>
    .bottomPage{
		width: 300px;
		overflow: hidden;
		display: flex;
		margin: 15px auto;
		&-box{
			width: 100px;
			overflow: hidden;
			text-align: center;
			&-font{
				color: #ddd;
				&.active{
					color: #333;
					cursor: pointer;
				}
			}
		}
	}
</style>

