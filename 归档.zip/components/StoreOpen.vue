<template>
	<view class="content">
	    <cl-message ref="message"/>
		<!-- 添加加盟商 -->
		<cl-popup :visible.sync="windows.Clerk" kuan="450px" direction="right">
			<cl-list label="请确保录入信息与门店营业执照法人信息一致" justify="start"></cl-list>
			<cl-list label="真实姓名" justify="start">
			    <cl-input v-model="form.clerk.Name" placeholder="真实姓名"></cl-input>
			</cl-list>
			<cl-list label="身份证号" justify="start">
			    <cl-input type="number" v-model="form.clerk.Ctizen" placeholder="身份证号码"></cl-input>
			</cl-list>
			<cl-list label="手机号码" justify="start">
			    <cl-input type="number" v-model="form.clerk.Phone" placeholder="手机号码"></cl-input>
			</cl-list>
			<cl-list label="请上传有效期内的身份证正反面" justify="start"></cl-list>
			<cl-list label="证件照片" justify="start">
			    <cl-upload v-model="form.clerk.Ctizen_Url" :size="['80px', '80px']" multiple :limit="2"></cl-upload>
			</cl-list>
			<cl-list label="结算渠道" justify="start">
			    <cl-select v-model="form.clerk.Collection_Bank" :options="bank"></cl-select>
			</cl-list>
			<cl-list label="结算方式" justify="start">
			    <cl-select v-model="form.clerk.Settlement_Mode" :options="mode"></cl-select>
			</cl-list>
			<cl-list label="结算账户" justify="start">
			    <cl-input v-model="form.clerk.Collection_Account" placeholder="为保证结算成功,请输入后核对信息"></cl-input>
			</cl-list>
			<cl-list label="开户地址" justify="start">
			    <cl-input v-model="form.clerk.Collection_Address" placeholder="银行结算模式需要填写"></cl-input>
			</cl-list>
			<cl-list label="结算周期" justify="start">
			    <cl-input disabled v-model="form.clerk.Settlement_Length"></cl-input>
			</cl-list>
			<cl-list label="结算费率" justify="start">
			    <cl-input disabled v-model="form.clerk.Settlement_Rate"></cl-input>
			</cl-list>
			<cl-list label="结算费率与周期将伴随合作深度进行调整" justify="start"></cl-list>
			<cl-list justify="start">
			   <cl-button type="primary" size="small" @click="clerkSave()">添加保存</cl-button>
			</cl-list>
		</cl-popup>
		<!-- 添加加盟商 -->
		<!-- 选择加盟商 -->
		<cl-popup :visible.sync="windows.ChooseClerk" kuan="550px" direction="right">
			<cl-grid>
			    <cl-grid-item isTitle width="30%">姓名</cl-grid-item>
				<cl-grid-item isTitle width="40%">身份证号码</cl-grid-item>
				<cl-grid-item isTitle width="30%">操作</cl-grid-item>
				<block v-for="item in clerk" :key="item.Id">
					<cl-grid-item width="30%">{{item.Name}}</cl-grid-item>
					<cl-grid-item width="40%">{{item.Ctizen}}</cl-grid-item>
					<cl-grid-item width="30%">
						<cl-button size="mini" type="primary" @click="ChooseThis(item)">选择Ta</cl-button>
					</cl-grid-item>
				</block>
			</cl-grid>
		</cl-popup>
		<!-- 选择加盟商 -->
		<!-- 地图坐标定位 -->
		<cl-popup v-if="windows.Map" :visible.sync="windows.Map" kuan="900px" gao="600px" direction="center" >
			<map id="store" style="width: 100%; height: 560px;" :scale="scale" :latitude="form.store.City.Latitude" :longitude="form.store.City.Longitude" :markers="markers" @regionchange="Mapmove">
				<cover-view class="map">
					<cl-button style="margin-left: 6px;" size="mini" type="primary" :disabled="scale <= 5" @click="scale--">放大视野</cl-button>
					<cl-button style="margin-left: 6px;" size="mini" type="primary" :disabled="scale >= 17" @click="scale++">缩小视野</cl-button>
					<cl-button style="margin-left: 6px;" size="mini" type="primary" @click="useItude()">确定位置</cl-button>
				</cover-view>
			</map>
		</cl-popup>
		<!-- 地图坐标定位 -->
		<!-- 门店开通结果 -->
		<cl-popup v-if="store" :visible.sync="windows.Store" kuan="400px" gao="280px" direction="center" >
			<cl-list justify="center">
				<cl-icon name="cl-icon-toast-success" :size="60" color="#06c820"></cl-icon>
			</cl-list>
			<cl-list justify="center">门店编号：{{store.Id}}</cl-list>
			<cl-list justify="center">商家系统证书将在24小时内签发完成</cl-list>
			<cl-list justify="center">请区域管理人员及时同步门店地理节点</cl-list>
		</cl-popup>
		<!-- 门店开通结果 -->
		<view class="content-open">
			<cl-button type="default" size="small" @click="open('Clerk')">新增加盟商</cl-button>
			<cl-button type="primary" size="small" @click="openStore(4)"  :loading="loading[4]">提交开通</cl-button>
		</view>
		<scroll-view scroll-y class="content-box">
			<view class="content-box-edit">
				<view>
					<cl-list label="获取店号:" justify="start">
					    <cl-input disabled v-model="form.store.Id" placeholder="以最终开通时获得的店号为准">
							<cl-button size="mini" slot="append" type="primary" :loading="loading[0]" @click="GetData('CreateStoreId',0)">生成店号</cl-button>
						</cl-input>
					</cl-list>
					<cl-list label="新店名称:" justify="start">
					    <cl-input v-model="form.store.Name" placeholder="如: 童店二区店"></cl-input>
					</cl-list>
					<cl-list label="配送范围:" justify="start">
					    <cl-input type="number" v-model="form.store.Range" placeholder="3000-5000">
							<text slot="append">米</text>
						</cl-input>
					</cl-list>
					<cl-list label="营业执照:" justify="start">
					    <cl-input v-model="form.store.Business_License" placeholder="营业执照编号"></cl-input>
					</cl-list>
					<cl-list label="拍照上传:" justify="start">
					    <cl-upload v-model="form.store.Business_License_Image" :size="['100px', '100px']" :limit="1"></cl-upload>
					</cl-list>
					<cl-list label="加盟费用:" justify="start">
					    <cl-input type="number" v-model="form.store.Join_Price" placeholder="如: 5000"><text slot="append">元</text></cl-input>
					</cl-list>
					<cl-list label="合同编号:" justify="start">
					    <cl-input v-model="form.store.Join_License" placeholder="如: TYM202010240001"></cl-input>
					</cl-list>
				</view>
				<view>
					<cl-list label="归属区域:" justify="start">
						<cl-input disabled v-model="form.store.City.Name" placeholder="归属区域">
							<cl-button size="mini" slot="append" type="primary" :loading="loading[1]" @click="GetData('ChooseCity',1)">选择区域</cl-button>
						</cl-input>
					</cl-list>
					<cl-list label="门店地址:" justify="start">
					    <cl-input v-model="form.store.Address" placeholder="如: 浙江省金华市义乌市稠江街道童店二区20幢1单元"></cl-input>
					</cl-list>
					<cl-list label="手机号码:" justify="start">
					    <cl-input type="number" v-model="form.store.Phone" placeholder="店内电话"></cl-input>
					</cl-list>
					<cl-list label="卫生许可:" justify="start">
					    <cl-input v-model="form.store.Food_License" placeholder="卫生许可证编号"></cl-input>
					</cl-list>
					<cl-list label="拍照上传:" justify="start">
					    <cl-upload v-model="form.store.Food_License_Image" :size="['100px', '100px']" :limit="1"></cl-upload>
					</cl-list>
					<cl-list label="保证金额:" justify="start">
					    <cl-input type="number" v-model="form.store.Join_Money" placeholder="如: 10000">
							<text slot="append">元</text>
						</cl-input>
					</cl-list>
				</view>
				<view>
					<cl-list label="加盟对象:" justify="start">
					    <cl-input disabled v-model="form.store.Clerk.Name" placeholder="选择加盟商">
					    	<cl-button size="mini" slot="append" type="primary"  :loading="loading[2]" @click="GetData('ChooseClerk',2)">选择对象</cl-button>
					    </cl-input>
					</cl-list>
					<cl-list label="位置坐标:" justify="start">
						<cl-input disabled :value="form.store.Location.Latitude ? form.store.Location.Latitude +','+form.store.Location.Longitude : null" placeholder="使用地图选择">
							<cl-button size="mini" slot="append" type="primary" @click="open('Map')">打开地图</cl-button>
						</cl-input>
					</cl-list>
					<cl-list label="拓展督导:" justify="start">
						<cl-input disabled v-model="form.store.Promoter.Name" placeholder="指定该店拓展人员">
							<cl-button size="mini" slot="append" type="primary" :loading="loading[3]" @click="GetData('ChooseUser',3)">选择员工</cl-button>
						</cl-input>
					</cl-list>
					<cl-list label="健康证号:" justify="start">
					    <cl-input v-model="form.store.Healthy_License" placeholder="健康证编号"></cl-input>
					</cl-list>
					<cl-list label="拍照上传:" justify="start">
					    <cl-upload v-model="form.store.Healthy_License_Image" :size="['100px', '100px']" :limit="1"></cl-upload>
					</cl-list>
					<cl-list label="门店商圈:" justify="start">
					    <cl-input disabled v-model="form.store.Shop_Cut.Name" placeholder="选择对应的商圈">
							<cl-button size="mini" slot="append" type="primary" :loading="loading[5]" @click="GetData('ChooseShopCut',5)">选择商圈</cl-button>
						</cl-input>
					</cl-list>
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	export default {
		components: {
			
		},
		props: {
			menuId:null
		},
		data() {
			return {
				form :{
					store: {
						Id: null,
						Address: null,
						Range: null,
						Business_License: null,
						Business_License_Image: null,
						Join_Price: null,
						Promoter: {Id: null, Name: null},
						Name: null,
						Location: {Latitude: null,Longitude: null},
						City: {Id: null, Name: null},
						Food_License: null,
						Food_License_Image: null,
						Join_Money: null,
						Clerk: {Id: null, Name: null},
						Phone: null,
						Healthy_License: null,
						Healthy_License_Image: null,
						Shop_Cut: {Name:null},
						Join_License: null,
					},
					clerk:{
						Name: null,
						Ctizen: null,
						Phone: null,
						Ctizen_Url: [],
						Collection_Bank: 0,
						Settlement_Mode: 0,
						Collection_Account: null,
						Collection_Address: null,
						Settlement_Length: "48小时",
						Settlement_Rate: "0.8%"
					}
				},
				windows:{Clerk: false, ChooseClerk: false, Map: false, Store: false},
				loading:[false, false, false, false, false, false, false],
				bank: [
					{label: '中国银行', value: 0},
				    {label: '微信分账', value: 1},
				    {label: '支付宝分账', value: 2},
					{label: '招商银行', value: 3},
				],
				mode: [
					{label: '手动提现', value: 0},
				    {label: '自动提现', value: 1}
				],
				clerk: [],
				store: null,
				scale: 15,
				markers: [{id: 1, width: 36, height: 36, latitude: 0, longitude: 0, iconPath: 'https://shanghai.image.taoyuanmi.com/css/dingwei.png'}]
			}
		},
		computed: {
			...mapState(['hasLogin','role','userInfo'])
		},
		created(){
			if(this.hasLogin){
				this.$socket.sendMessage({action: 'GetCosKey', token: this.userInfo.Token},this)
			}
		},
		methods:{
			//提交开通申请
			openStore(index){
				this.$set(this.loading,index,true)
				this.$socket.sendMessage({action: 'openStore', menu: this.menuId, form: this.form.store, button: index, token: this.userInfo.Token},this)
			},
			//确认门店坐标
			useItude(){
				this.windows.Map = false
				this.form.store.Location.Latitude = this.markers[0].latitude
				this.form.store.Location.Longitude = this.markers[0].longitude
			},
			//地图中心点发生变化
			Mapmove(e){
				const that = this
				if(e.type == 'end'){
					const map = uni.createMapContext("store")
					map.getCenterLocation({
						success(res){
							that.$set(that.markers[0],'latitude',res.latitude)
							that.$set(that.markers[0],'longitude',res.longitude)
							map.translateMarker({
							    markerId: 1,  
							    destination: {longitude: res.longitude, latitude: res.latitude},  
							})
						}
					})
				}
			},
			//选择加盟商
			ChooseThis(clerk){
				this.windows.ChooseClerk = false
				this.form.store.Clerk = clerk
			},
			//加盟商信息保存
			clerkSave(){
				this.$socket.sendMessage({action: 'clerkSave', menu: this.menuId, form: this.form.clerk, token: this.userInfo.Token},this)
			},
			//打开窗口
			open(object){
				this.windows[object] = true
			},
			//获取数据
			GetData(action,index){
				this.$set(this.loading,index,true)
				this.$socket.sendMessage({action: action, menu: this.menuId, button: index, token: this.userInfo.Token},this)
			},
			//信息接收
			onMessage(res){
				const that = this
				let index = null
				let itemList = []
				switch (res.action) {
					case 'CreateStoreId':
					    this.$set(this.loading,res.button,false)
						this.form.store.Id = res.data
					break
					case 'ChooseCity':
					    this.$set(this.loading,res.button,false)
						res.data.forEach(item=>{
							itemList.push(item.Name)
						})
						uni.showActionSheet({
						    itemList: itemList,
						    success: function (city) {
								that.$set(that.markers[0],'latitude',res.data[city.tapIndex].Latitude)
								that.$set(that.markers[0],'longitude',res.data[city.tapIndex].Longitude)
								that.form.store.City = {Id: res.data[city.tapIndex].Id, Name: res.data[city.tapIndex].Name, Latitude: res.data[city.tapIndex].Latitude, Longitude: res.data[city.tapIndex].Longitude}
							}
						})
					break
					case 'ChooseShopCut':
					    this.$set(this.loading,res.button,false)
					    res.data.forEach(item=>{
					    	itemList.push(item.Name)
					    })
					    uni.showActionSheet({
					        itemList: itemList,
					        success: function (cut) {
					    		that.form.store.Shop_Cut = res.data[cut.tapIndex]
					    	}
					    })
					break;
					case 'ChooseUser':
					    this.$set(this.loading,res.button,false)
						if(res.data.length > 0){
							res.data.forEach(item=>{
								itemList.push(item.Name)
							})
							uni.showActionSheet({
							    itemList: itemList,
							    success: function (item) {
									that.form.store.Promoter = res.data[item.tapIndex]
								}
							})
						}
					break
					case 'clerkSave':
					    this.windows.Clerk = false
						this.form.clerk = {
						    Name: null,
						    Ctizen: null,
							Phone: null,
						    Ctizen_Url: [],
						    Collection_Bank: 0,
						    Settlement_Mode: 0,
						    Collection_Account: null,
						    Collection_Address: null,
						    Settlement_Length: "48小时",
						    Settlement_Rate: "0.8%"
					    }
						this.$refs["message"].open({
						    message: res.data,
							type: 'success_no_circle'
						})
					break
					case 'ChooseClerk':
					    this.$set(this.loading,res.button,false)
					    this.clerk = res.data
						this.windows.ChooseClerk = true
					break
					case 'openStore':
					    this.$set(this.loading,res.button,false)
					    this.windows.Store = true
						this.form.store = {
						    Id: null,
						    Address: null,
						    Range: null,
						    Business_License: null,
						    Business_License_Image: null,
						    Join_Price: null,
						    Promoter: {Id: null, Name: null},
						    Name: null,
						    Location: {Latitude: null,Longitude: null},
						    City: {Id: null, Name: null},
						    Food_License: null,
						    Food_License_Image: null,
						    Join_Money: null,
						    Clerk: {Id: null, Name: null},
						    Phone: null,
						    Healthy_License: null,
						    Healthy_License_Image: null,
							Shop_Cut: {Name:null},
						    Join_License: null,
					    }
					    this.store = {Id: res.Id}
					break
				}
			},
		}
	}
</script>

<style lang="scss">
	.map{
		padding: 10upx 20upx;
		float: right;
		display: flex;
	}
	.content{
		overflow: hidden;
		width: calc(100% - 40rpx);
		height: calc(100% - 30rpx);
		padding: 10rpx;
		margin: 0 10rpx 10rpx;
		background: #fff;
		border-radius: 10rpx;
		&-open{
			height: 40px;
			overflow: hidden;
			display: flex;
			> *{
				margin-right: 10rpx;
			}
		}
		&-box{
			height: calc(100% - 40px);
			overflow: hidden;
			&-edit{
				height: 100%;
				display: grid;
				grid-template-columns: 33.333% 33.333% 33.333%;
			}
		}
	}
</style>