<template>
	<view class="content">
	    <text>运营</text>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	export default {
		props: {
			
		},
		data() {
			return {
				
			}
		},
		computed: {
			...mapState(['userInfo']),
		}
	}
</script>

<style lang="scss">
	.content{
		overflow: hidden;
		width: calc(100% - 40rpx);
		height: calc(100% - 30rpx);
		padding: 10rpx;
		margin: 0 10rpx 10rpx;
		background: #fff;
		border-radius: 10rpx;
	}
</style>
