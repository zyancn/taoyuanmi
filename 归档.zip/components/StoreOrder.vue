<template>
	<view class="com">
		<view class="com-left">
			<cl-message ref="message"/>
			<view class="com-action">
				<text>下单日期：</text>
				<cl-tag type="primary" :plain="!(orderChange.date.start==null)" @click="orderChange.date.start=orderChange.date.end=null">今天</cl-tag>
				<cl-select placeholder="开始时间" v-model="orderChange.date.start" mode="date" ></cl-select>
				<text>-</text>
				<cl-select placeholder="结束时间" :start="orderChange.date.start" v-model="orderChange.date.end" mode="date" ></cl-select>
				<text></text>
				<text>订单状态：</text>
				<block v-for="(item,m) in orderChange.status.data" :key="m">
					<cl-tag type="primary" :plain="!(orderChange.status.choose==m)" @click="orderChange.status.choose=m">{{item.name}}</cl-tag>
				</block>
			</view>
			<view class="com-page">
				<scroll-view scroll-y class="com-page-box">
					<block v-if="order.length == 0">
						<image class="com-page-box-image" style="width: 209px;height: 150px;" src="/static/orderempty.png" mode=""></image>
					</block>
					<block v-else>
						<block v-for="(item,n) in order" :key="n">
							<view class="com-page-box-list">
								<view class="com-page-box-list-box">
									<text class="cl-icon-primary cl-icon-bold">No.{{item.Id}}</text>
									<text class="cl-icon-button">{{status[item.Status]}}</text>
								</view>
								<view class="com-page-box-list-box">
									<view class="com-page-box-list-box-info">
										<view class="com-page-box-list-box-info-content">
											<text class="cl-icon-bold">{{item.Count}}样菜品 {{item.Dinner_Amount}}份餐具</text>
											<view v-if="!item.Foods">
												<text @click="readAction(item)">查看菜品</text>
												<cl-icon name="cl-icon-arrow-bottom"></cl-icon>
											</view>
										</view>
										<block v-for="(food,index) in item.Foods" :key="index">
											<view class="com-page-box-list-box-info-content">
												<text><font :style="food.Count > 1 ? 'color:#ee4a4a':''">{{food.Count}}份</font> × {{food.Title}} [{{food.Choose}}]</text>
												<text>￥{{food.Count * food.Price|toMoney(2)}}</text>
											</view>
										</block>
									</view>
									<view class="com-page-box-list-box-info">
										<view class="com-page-box-list-box-info-content">
											<text>联系方式：</text>
											<text>{{item.Name}} {{item.Phone}}</text>
										</view>
										<view class="com-page-box-list-box-info-content">
											<text>用餐地点：</text>
											<text>{{item.Address}}</text>
										</view>
									</view>
									<view class="com-page-box-list-box-info">
										<view class="com-page-box-list-box-info-content" v-if="item.Cash">
											<text>优惠金额：</text>
											<text class="cl-icon-bold">{{item.Cash.Name}} -￥{{item.Cash.Part|toMoney(2)}}</text>
										</view>
										<view class="com-page-box-list-box-info-content">
											<text>配送费用：</text>
											<text class="cl-icon-bold">{{item.Send_Cash_Id > 0 ? '5.00' : '免配送费'}}</text>
										</view>
										<view class="com-page-box-list-box-info-content">
											<text>实付金额：</text>
											<text class="cl-icon-money cl-icon-bold">￥{{item.Price|toMoney(2)}}</text>
										</view>
										<view class="com-page-box-list-box-info-content">
											<text>支付方式：</text>
											<text>{{pay[item.Pay_Cut]}}</text>
										</view>
									</view>
								</view>
								<view class="com-page-box-list-box">
									<view class="com-page-box-list-box-left">
										<view>下单时间：{{item.Create_Time|forDate(true)}}</view>
										<view>支付单号：<text :class="come[item.Come]"></text> {{item.Pay_Transaction_Id}}</view>
									</view>
									<view class="com-page-box-list-box-right">
										<block v-for="b in orderButton" :key="b.id">
											<cl-button v-if="canUseButton(b,item.Status)" :type="b.type" :icon='b.class' @click="orderAction(b.id,item.Id)">{{b.name}}</cl-button>
										</block>
									</view>
								</view>
							</view>
						</block>
					</block>
					<Page :length="order.length" :max="20" @change="turnPage"></Page>
				</scroll-view>
			</view>
		</view>
		<view class="com-right">
			<view class="com-count">
				<view class="com-count-line">
					<text class="kangchi-bold">今日汇总</text>
				</view>
				<view class="com-count-line">
					<text>预计总收入<text class="cl-icon-number">￥{{today.Price|toMoney(2)}}</text>元</text>
				</view>
				<view class="com-count-line">
					<view>
						<cl-icon name="cl-icon-yuan" color="#74eea5"></cl-icon>
						<text>已完成<text class="cl-icon-number">{{today.endorder}}</text>单</text>
					</view>
				</view>
				<view class="com-count-line">
					<view>
						<cl-icon name="cl-icon-yuan" color="#5bc7ee"></cl-icon>
						<text>进行中<text class="cl-icon-number">{{today.runorder}}</text>单</text>
					</view>
				</view>
				<view class="com-count-line">
					<view>
						<cl-icon name="cl-icon-yuan" color="#ffd15c"></cl-icon>
						<text>超时未接<text class="cl-icon-number">{{today.outorder}}</text>单</text>
					</view>
				</view>
				<view class="com-count-line">
					<view>
						<cl-icon name="cl-icon-yuan" color="#ff9595"></cl-icon>
						<text>取消拒单<text class="cl-icon-number">{{today.gotorder}}</text>单</text>
					</view>
				</view>
			</view>
			<view class="com-count">
				<view class="com-count-line">
					<text class="kangchi-bold">今日销量排行</text>
					<cl-icon name="cl-icon-refresh cl-icon-button"></cl-icon>
				</view>
				<view class="com-count-line">
					<text>香喷喷的米饭</text>
					<text>× 10</text>
				</view>
				<view class="com-count-line">
					<text>红烧鸡爪</text>
					<text>× 6</text>
				</view>
				<view class="com-count-line">
					<text>酱汁排骨</text>
					<text>× 6</text>
				</view>
				<view class="com-count-line">
					<text>啤酒鸭</text>
					<text>× 6</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	import Page from '@/components/Page'
	export default {
		components: {
			Page
		},
		props: {
			menuId:null
		},
		data() {
			return {
				come: ['cl-icon-right cl-icon-wechat','cl-icon-right cl-icon-alipay'],
				pay: ['未支付','微信支付','支付宝'],
				mode: ['到店自取','骑手配送'],
				status: {
					'100': "等待接单",
					'101': "已拒绝",
					'102': "接单超时",
					'200': "已接单",
					'201': "烹饪中",
					'202': "等待出餐",
					'300': "等待配送",
					'301': "等待自取",
					'302': "正在配送",
					'400': "配送完成",
					'500': "等待售后",
					'602': "等待退款处理",
					'700': "已完成",
					'800': "已取消",
				},
				order: [],
				orderChange: {
					store: null,
					page: 1,
					date: {
						start: null,
						end: null
					},
					status:{
						choose : 1,
						data: [
						    {name: "全部", value: [2,100,101,111,102,112,200,201,202,300,301,302,400,401,402]},
						    {name: "进行中", value: [100,200,201,202,300,301,302]},
						    {name: "完成", value: [400,401,402]},
						    {name: "投诉", value: [111,112,401,402]}
					    ]
					}
				},
				orderButton: [
					{id: 0, name: '打印小票', type: 'default', class: 'cl-icon-dayinji', status: [100,200,201,202,300,301,302,400,401,402]}, //打印
					{id: 3, name: '部分退款', type: 'default', class: 'cl-icon-collect', status: [100,200,201,202,300,301,302,400,401]}, //部分退款
					{id: 1, name: '接受订单', type: 'success', class: 'cl-icon-check', status: [100]}, //接受订单
					{id: 2, name: '拒绝订单', type: 'error', class: 'cl-icon-close', status: [100]}, //拒绝订单
					{id: 4, name: '开始烹饪', type: 'error', class: 'cl-icon-pengren', status: [200]}, //备菜完成开始烹饪
					{id: 5, name: '预约配送', type: 'success', class: 'cl-icon-peisong', status: [200,201,202]}, //烹饪到出餐的过程可以随时预约骑手
					{id: 6, name: '开始包装', type: 'error', class: 'cl-icon-canhefanhe', status: [201]}, //结束烹饪 开始包装
					{id: 7, name: '确认出餐', type: 'error', class: 'cl-icon-mark', status: [202]}, //包装完成 确认出餐
				],
				today:{
					Price: 0,
					endorder: 0,
					gotorder: 0,
					outorder: 0,
					runorder: 0,
				}
			};
		},
		computed: {
			...mapState(['hasLogin','role','userInfo','store']),
			choose(){
				return this.store.choose
			},
			canUseButton(){
				return function (b,status){
					return b.status.findIndex(s=>s==status) > -1 ? true : false
				}
			}
		},
		watch: {
			choose(newData,oldData){
				let tmp = this.orderChange
				tmp.store = newData
				tmp.page = 1
				this.orderChange = tmp
			},
			orderChange:{
				handler(newData,oldData){
					this.order = []
					setTimeout(()=>{
						this.$socket.sendMessage({action: 'GetStoreOrder', change: newData, menu: this.menuId, token: this.userInfo.Token},this)
						this.$socket.sendMessage({action: 'GetTodayStoreOrderCount', store: newData.store, menu: this.menuId, token: this.userInfo.Token},this)
					}, 800);
				},deep: true
			},
		},
		created() {
			//进入页面 更新右侧汇总信息 同步当前选中的门店
			if(this.hasLogin){
				this.orderChange.store = this.store.choose
			}
		},
		methods:{
			turnPage(page){
				this.orderChange.page = page
			},
			orderAction(action,order){
				this.$socket.sendMessage({action: 'orderAction', store: this.orderChange.store, menu: this.menuId, cut: action, order: order, token: this.userInfo.Token},this)
			},
			readAction(order){
				if(!order.Foods){
					this.$socket.sendMessage({action: 'orderAction', store: this.orderChange.store, menu: this.menuId, cut: -1, order: order.Id, token: this.userInfo.Token},this)
				}
			},
			onMessage(res){
				switch (res.action) {
					case 'GetStoreOrder':
					    this.order = res.data
					break
					case 'orderFoods':
					    this.$set(this.order,this.order.findIndex(order=>order.Id == res.data.Id),res.data)
					break
					case 'orderPrint':
						this.print(0,res.data,1)
					break
					case 'orderInfo':
						this.$set(this.order,this.order.findIndex(order=>order.Id == res.data.Id),res.data)
					break;
					case 'neworder':
					    this.order.unshift(res.data)
					break
					case 'GetTodayStoreOrderCount':
					    this.today = res.data
					break
				}
			},
		}
	}
</script>

<style lang="scss">
    .com{
		overflow: hidden;
		width: calc(100% - 40rpx);
		height: calc(100% - 30rpx);
		padding: 10rpx;
		margin: 0 10rpx 10rpx;
		background: #fff;
		border-radius: 10rpx;
		display: flex;
		text + text{
			margin-left: 10rpx;
		}
		&-left{
			width: calc(100% - 300rpx);
		}
		&-right{
			width: 220rpx;
			padding: 0 40rpx;
		}
		&-action{
			display: flex;
			height: 35rpx;
			line-height: 35rpx;
			overflow: hidden;
			padding-bottom: 15rpx;
			border-bottom: 1rpx solid #eee;
			align-items: center;
			> *{
				margin-right: 10rpx;
				overflow: hidden;
				text-overflow:ellipsis;
				white-space: nowrap;
			}
		}
		&-count{
			padding: 20rpx 0;
			width: 100%;
			&-line{
				display: flex;
				justify-content: space-between;
				line-height: 40rpx;
			}
		}
		&-count + &-count{
			border-top: 1rpx solid #eee;
		}
		&-page{
			width: 100%;
			padding: 15rpx 0 0;
			height: calc(100% - 65rpx);
		    overflow: hidden;
			&-box{
				width: 100%;
				height: 100%;
				overflow: hidden;
				&-image{
					position: absolute;
					left:0; 
					right:0; 
					top:0; 
					bottom:0;
					margin: auto;
				}
				&-list{
					overflow: hidden;
					background-color: #fff;
					margin-bottom: 25rpx;
					transition: all 0.3s;
					border: 1rpx solid #eee;
					&-box{
						overflow: hidden;
						padding: 15rpx 20rpx;
						line-height: 26rpx;
						&-info{
							overflow: hidden;
							padding: 10rpx 0 10rpx 60rpx;
							&-content{
								display: flex;
								justify-content: space-between;
								line-height: 40rpx;
							}
							&-content:hover{
								background-color: #f8f8f8;
							}
							&-content + &-content{
								border-top: 1rpx dashed #f1f1f1;
							}
						}
						&-info + &-info{
							border-top: 1rpx solid #eee;
						}
						&-left{
							color: #666;
						}
						&-right{
							> *{
								margin-left: 10rpx;
							}
						}
					}
					&-box:first-child{
						background-color: #f8f8f8;
						display: flex;
						justify-content: space-between;
					}
					&-box:last-child{
						border-top: 1rpx solid #eee;
						display: flex;
						justify-content: space-between;
					}
				}
			}
		}
	}
</style>
