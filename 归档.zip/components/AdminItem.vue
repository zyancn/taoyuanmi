<template>
	<view class="content">
		<cl-message ref="message"/>
		<cl-popup :visible.sync="visible.cut" gao="400px" kuan="800px" direction="center" class="content-popop">
			<view class="content-popop-title">商品分类 (暂不开放相关操作)</view>
			<cl-grid :column="6" class="content-box-line content-box-head">
			    <cl-grid-item width="10%">名称</cl-grid-item>
				<cl-grid-item width="10%">展示图</cl-grid-item>
				<cl-grid-item width="10%">分类</cl-grid-item>
				<cl-grid-item width="10%">创建时间</cl-grid-item>
				<cl-grid-item width="10%">创建人</cl-grid-item>
				<cl-grid-item width="10%">操作</cl-grid-item>
			</cl-grid>
			<cl-grid :column="6" border class="content-box-line">
				<block v-for="item in cut" :key="item.Id">
					<cl-grid-item width="10%">{{item.Name}}</cl-grid-item>
					<cl-grid-item width="10%">
						<image class="content-box-line-item-icon" :src="item.Url" mode=""></image>
					</cl-grid-item>
					<cl-grid-item width="10%">{{getCut(item.Cut)}}</cl-grid-item>
					<cl-grid-item width="10%">{{item.Create_Time|forDate}}</cl-grid-item>
					<cl-grid-item width="10%">{{item.User}}</cl-grid-item>
					<cl-grid-item width="10%">
						<text class="content-box-line-item-action" @click="deleteItemCut(item.Id)">删除</text>
					</cl-grid-item>
				</block>
			</cl-grid>
		</cl-popup>
		<cl-popup :visible.sync="visible.add" kuan="500px" direction="right" class="content-popop" v-if="form.add">
			<cl-list label="商品分类" justify="start">
			    <cl-select v-model="form.add.Cut" :options="getCutSelect"></cl-select>
			</cl-list>
			<cl-list label="推荐级别" justify="start">
			    <cl-radio-group v-model="form.add.Rank">
			    	<block v-for="(item,index) in rank" :key="index">
			    		<cl-radio :label="item.value">{{item.name}}</cl-radio>
			    	</block>
			    </cl-radio-group>
			</cl-list>
            <cl-list label="商品名称" justify="start">
                <cl-input v-model="form.add.Title" placeholder="商品名称"></cl-input>
            </cl-list>
			<cl-list label="品牌名称" justify="start">
			    <cl-input class="content-popop-list" v-model="form.add.Brand" placeholder="商品品牌"></cl-input>
				<cl-checkbox class="content-popop-list content-popop-button" v-model="form.add.Self" label="1">自营</cl-checkbox>
				<cl-checkbox class="content-popop-button" v-model="form.add.Cash" label="1">优惠券</cl-checkbox>
			</cl-list>
			<cl-list label="材质净重" justify="start">
			   <cl-input class="content-popop-list" v-model="form.add.Material" placeholder="材质"></cl-input>
			   <cl-input v-model="form.add.Weight" placeholder="净重"></cl-input>
			</cl-list>
			<cl-list label="购买价格" justify="start">
			   <cl-input type="number" class="content-popop-list" v-model="form.add.Old_Price" placeholder="原价"><text slot="append">分</text></cl-input>
			   <cl-input type="number" class="content-popop-list" v-model="form.add.Price" placeholder="现价"><text slot="append">分</text></cl-input>
			   <cl-input type="number" v-model="form.add.Integral" placeholder="所需积分"><text slot="append">积分</text></cl-input>
			</cl-list>
			<view style="background-color: #f4f4f4;margin: 10px 0; padding:5px">
				<block v-for="(stock,index) in form.add.Stock" :key="index">
				    <cl-list :label="(index+1) | numText" justify="start">
				       	<cl-input class="content-popop-list" v-model="stock.Style" placeholder="款式"></cl-input>
				       	<cl-input type="number" class="content-popop-list" v-model="stock.Count" placeholder="数量"></cl-input>
				       	<cl-button class="content-popop-button" type="primary" @click="addStock()" v-if="index==0">添加</cl-button>
				       	<cl-button class="content-popop-button" type="default" @click="deleteStock(index)" v-else>删除</cl-button>
				    </cl-list>
				</block>
			</view>
			<cl-list label="兑换条件" justify="start">
			   <cl-input type="number" class="content-popop-list" v-model="form.add.GetRank[0]" placeholder="注册时间"><text slot="append">天</text></cl-input>
			   <cl-input type="number" class="content-popop-list" v-model="form.add.GetRank[1]" placeholder="用户评级"><text slot="append">级</text></cl-input>
			   <cl-input type="number" v-model="form.add.GetRank[2]" placeholder="近30天消费额"><text slot="append">分</text></cl-input>
			</cl-list>
			<cl-list label="发货周期" justify="start">
			   <cl-input type="number" v-model="form.add.PostTime" placeholder="发货周期"><text slot="append">小时</text></cl-input>
			</cl-list>
            <cl-list label="限购信息" justify="start">
			   <cl-input type="number" class="content-popop-list" v-model="form.add.Length" placeholder="限购周期"><text slot="append">秒</text></cl-input>
			   <cl-input type="number" v-model="form.add.Limits" placeholder="限购数量"><text slot="append">件</text></cl-input>
			</cl-list>
			<cl-list label="销售时间" justify="right">
				<Time class="content-popop-list" :defaultValue="form.add.Start | forDate(true)" variable="Start" @change="TimeChange"></Time>
				<text class="content-popop-list">-</text>
				<Time class="content-popop-list" :defaultValue="form.add.End | forDate(true)" variable="End" @change="TimeChange"></Time>
			</cl-list>
			<cl-list label="商品描述" justify="start">
			   <cl-input v-model="form.add.Describe" placeholder="一句话描述 100字以内"></cl-input>
			</cl-list>
			<cl-list label="商品主图" justify="start">
			   <cl-upload v-model="form.add.Image_Url" :size="['100px', '100px']" :limit="1"></cl-upload>
			</cl-list>
			<cl-list label="商品详情" justify="start">
			   <cl-upload v-model="form.add.Image" :size="['100px', '100px']" multiple :limit="100"></cl-upload>
			</cl-list>
			<cl-list justify="start">
				 <cl-button type="primary" @click="Item()" round>提交保存</cl-button>
			</cl-list>
		</cl-popup>
		<cl-popup :visible.sync="visible.sell" gao="400px" kuan="800px" direction="center" class="content-popop" v-if="form.sell">
			<view class="content-popop-title">{{form.sell.Title + ' 销售记录'}}</view>
			<cl-grid :column="5" class="content-box-line content-box-head">
			    <cl-grid-item width="10%">下单时间</cl-grid-item>
				<cl-grid-item width="10%">款式</cl-grid-item>
				<cl-grid-item width="10%">数量</cl-grid-item>
				<cl-grid-item width="10%">收件人</cl-grid-item>
				<cl-grid-item width="10%">状态</cl-grid-item>
			</cl-grid>
			<cl-grid :column="5" border class="content-box-line">
				<block v-for="order in his" :key="order.Id">
					<cl-grid-item width="10%">{{order.Time|forDate(true)}}</cl-grid-item>
					<cl-grid-item width="10%">{{order.Choose}}</cl-grid-item>
					<cl-grid-item width="10%">{{order.Count}}</cl-grid-item>
					<cl-grid-item width="10%">{{order.Logistics_Name}}</cl-grid-item>
					<cl-grid-item width="10%">{{order.OrderStatus|getStatus}}</cl-grid-item>
				</block>
			</cl-grid>
		</cl-popup>
	    <view class="content-action">
	    	<cl-button type="primary" size="mini" @click="action('add')">增加商品</cl-button>
			<cl-button type="default" size="mini" @click="action('cut')">分类管理</cl-button>
			<cl-button type="default" size="mini" @click="action('set')">运费设置</cl-button>
			<cl-button type="default" size="mini" @click="action('task')">促销管理</cl-button>
	    </view>
		<scroll-view scroll-y class="content-box">
			<cl-grid :column="10" class="content-box-line content-box-head">
			    <cl-grid-item width="8%">主图</cl-grid-item>
				<cl-grid-item width="16%">名称</cl-grid-item>
				<cl-grid-item width="10%">分类</cl-grid-item>
				<cl-grid-item width="10%">品牌</cl-grid-item>
				<cl-grid-item width="8%">已售</cl-grid-item>
				<cl-grid-item width="8%">库存</cl-grid-item>
				<cl-grid-item width="8%">限购</cl-grid-item>
				<cl-grid-item width="10%">开始</cl-grid-item>
				<cl-grid-item width="10%">结束</cl-grid-item>
				<cl-grid-item width="12%">操作</cl-grid-item>
			</cl-grid>
			<scroll-view scroll-y class="content-box-content">
				<cl-grid :column="10" border class="content-box-line">
					<block v-for="item in list" :key="item.Id">
						<cl-grid-item width="8%">
							<image class="content-box-line-item-icon" :src="item.Image_Url" mode=""></image>
						</cl-grid-item>
						<cl-grid-item width="16%">{{item.Title}}</cl-grid-item>
						<cl-grid-item width="10%">{{getCut(item.Cut)}}</cl-grid-item>
						<cl-grid-item width="10%">{{item.Brand ? item.Brand : '-'}}</cl-grid-item>
						<cl-grid-item width="8%">{{item.Sell}}</cl-grid-item>
						<cl-grid-item width="8%">{{getStock(item.Stock)}}件</cl-grid-item>
						<cl-grid-item width="8%">{{item.Limits}}件</cl-grid-item>
						<cl-grid-item width="10%">{{item.Start|forDate}}</cl-grid-item>
						<cl-grid-item width="10%">{{item.End|forDate}}</cl-grid-item>
						<cl-grid-item width="12%">
							<text class="content-box-line-item-action" @click="action('sell',item)">记录</text>
							<text class="content-box-line-item-action" @click="action('add',item)">编辑</text>
							<text class="content-box-line-item-action" v-if="isEnd(item.End)" @click="deleteItem(item.Id)">下架</text>
						</cl-grid-item>
					</block>
				</cl-grid>
				<view class="content-box-content-page">
					<view class="content-box-content-page-turn" @click="turnPage(page-1)">
						<cl-icon name="cl-icon-arrow-left" :size="20" :color="page == 1 ? '#ddd':'#333'"></cl-icon>
					</view>
					<view class="content-box-content-page-this">{{page}}</view>
					<view class="content-box-content-page-turn" @click="turnPage(page+1)">
						<cl-icon name="cl-icon-arrow-right" :size="20" :color="list.length < 15 ? '#ddd':'#333'"></cl-icon>
					</view>
				</view>
			</scroll-view>
		</scroll-view>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	import Time from '@/components/Time'
	export default {
		components: {
			Time
		},
		props: {
			menuId:null
		},
		data() {
			return {
				page: 1,
				visible: {cut: false, add: false, set: false, task: false, sell: false},
				list: [],
				cut: [],
				his:[],
				rank: [{name: '不推荐', value: 0}, {name: '分类推荐', value: 1}, {name: '首页推荐', value: 2}, {name: '滚动推荐', value: 3}],
				form: {
					add: null,
					sell: null,
				}
			}
		},
		computed: {
			...mapState(['hasLogin','role','userInfo']),
			getCut(){
				return function(that){
					return that==0 ? '-' : this.cut[this.cut.findIndex(cut=>cut.Id == that)].Name
				}
			},
			getStock(){
				return function(that){
					let count = 0
					let s = that.split(",")
					s.forEach(key=>{
						count += key/1
					})
					return count
				}
			},
			getCutSelect(){
				let res = []
				this.cut.forEach(item=>{
					res.push({label: item.Name, value: item.Id})
				})
				return res
			},
			isEnd(){
				return function(end){
					let now = new Date().getTime() / 1000
					return now < end ? true : false
				}
			}
		},
		created(){
			if(this.hasLogin){
				this.$socket.sendMessage({action: 'GetCosKey', token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetItemCut', menu: this.menuId, token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetItemList', menu: this.menuId, page: this.page, token: this.userInfo.Token},this)
			}
		},
		methods:{
			turnPage(page){
				console.log(page)
				if(page < 1){
					return
				}
				if(page > this.page && this.list.length < 15){
					return
				}
				this.page = page
				this.$socket.sendMessage({action: 'GetItemList', menu: this.menuId, page: page, token: this.userInfo.Token},this)
			},
			//信息接收
			onMessage(res){
				switch (res.action) {
					case 'GetItemList':
					    this.list = res.data
					break
					case 'GetItemCut':
					    this.cut = res.data
					break
					case 'Item':
					    this.visible.add = false
						let index = this.list.findIndex(item=>item.Id == res.data.Id)
						if(index == -1){
							this.list.push(res.data)
						}else{
							this.list[index] = res.data
						}
					break
					case 'deleteItem':
					    this.$refs["message"].open({
						    message: "已下架",
							type: 'success_no_circle'
						})
					    this.list[this.list.findIndex(item=>item.Id == res.data)].End = new Date().getTime() / 1000
					break
					case 'ItemHis':
					console.log(res.data)
					    this.his = res.data
					break
				}
			},
			//提交保存
			Item(){
				console.log(this.form.add)
				this.$socket.sendMessage({action: 'Item', form: this.form.add, menu: this.menuId, token: this.userInfo.Token},this)
			},
			action(e,data=null){
				this.visible[e] = true
				switch(e){
					case 'add':
					    this.form[e] = {
					    	Id:null,
					    	Cut: null,
					    	Rank: 0,
					    	Self: 0,
					    	Title: null,
					    	Brand: null,
					    	Material: null,
					    	Weight: null,
					    	Old_Price: null,
					    	Integral: null,
					    	Price: null,
					    	Cash: 0,
					    	GetRank:[null, null, null],
					    	Stock:[{Style: null, Count: null}],
					    	PostTime: null,
					    	Start: new Date().getTime() / 1000,
					    	End: new Date().getTime() / 1000,
					    	Describe: null,
					    	Image_Url: null,
					    	Image: []
					    }
					    if(data){
					    	this.form[e].Id = data.Id
					    	this.form[e].Cut = data.Cut
					    	this.form[e].Rank = data.Rank
					    	this.form[e].Title = data.Title
					    	this.form[e].Brand = data.Brand
					    	this.form[e].Self = data.Self
					    	this.form[e].Cash = data.Cash
					    	this.form[e].Material = data.Material
					    	this.form[e].Weight = data.Weight
					    	this.form[e].Old_Price = data.Old_Price
					    	this.form[e].Price = data.Price
					    	this.form[e].Integral = data.Integral
					    	this.form[e].Stock = []
					    	let style = data.Style.split(",")
					    	let count = data.Stock.split(",")
					    	style.forEach((v,k)=>{
					    		this.form[e].Stock.push({Style: v, Count: count[k]})
					    	})
					    	this.form[e].GetRank = data.GetRank.split(",")
					    	this.form[e].PostTime = data.PostTime
					    	this.form[e].Length = data.Length
					    	this.form[e].Limits = data.Limits
					    	this.form[e].Start = data.Start
					    	this.form[e].End = data.End
					    	this.form[e].Describe = data.Describe
					    	this.form[e].Image_Url = data.Image_Url
					    	this.form[e].Image = data.Image.split(",")
					    }
					break
					case 'sell':
					    this.form[e] = {Title:null}
						if(data){
							this.his = []
							this.form[e].Title = data.Title
							this.$socket.sendMessage({action: 'ItemHis', menu: this.menuId, id: data.Id, token: this.userInfo.Token},this)
						}
					break
				}
			},
			deleteItem(id){
				if(this.hasLogin){
					this.$socket.sendMessage({action: 'deleteItem', menu: this.menuId, id: id, token: this.userInfo.Token},this)
				}
			},
			addStock(){
				const that = this.form.add.Stock
				that.push({Style:null,Count:null})
				this.$set(this.form.add,'Stock',that)
			},
			deleteStock(stock){
				const that = this.form.add.Stock
				that.splice(stock,1)
				this.$set(this.form.add,'Stock',that)
			},
			TimeChange(e){
				this.$set(this.form.add,e.variable,new Date(e.date.f3).getTime() / 1000)
			}
		}
	}
</script>

<style lang="scss">
	.content{
		overflow: hidden;
		width: calc(100% - 40px);
		height: calc(100% - 30px);
		padding: 10px;
		margin: 0 10px 10px;
		background: #fff;
		&-popop{
			overflow: hidden;
			&-list{
				margin-right: 10px;
			}
			&-button{
				width: 150px;
			}
			&-title{
				margin-bottom: 20px;
			}
			&-line{
				display: grid;
				grid-template-columns: 15% 85%;
				margin: 15px 0;
				line-height: 35px;
				width: 100%;
				overflow: hidden;
				&-name{
					overflow: hidden;
				}
				&-content{
					padding: 0 5px 2px 0;
					text-align: center;
				}
			}
		}
		&-action{
			overflow: hidden;
			height: 40px;
		}
		&-box{
			height: calc(100% - 40px);
			overflow: hidden;
			&-content{
				height: calc(100% - 35px);
				overflow: hidden;
				&-page{
					padding: 20px 0;
					height: 20px;
					line-height: 20px;
					overflow: hidden;
					width: 140px;
					margin: auto;
					display: flex;
					&-turn{
						width: 20px;
						cursor: pointer;
					}
					&-this{
						width: 100px;
						text-align: center;
					}
				}
			}
			&-line{
				line-height: 50px;
				&-item{
					padding: 0 10px;
					overflow: hidden;
					text-overflow:ellipsis;
					white-space: nowrap;
					&-icon{
						width: 35px;
						height: 35px;
						vertical-align: middle;
					}
					&-action{
						color: #4165d7;
						margin-right: 10px;
						cursor: pointer;
					}
				}
				&-child{
					padding-left: 25px;
				}
			}
			&-head{
				background-color: #ebeef5;
			}
		}
	}
</style>