<template>
	<view class="content">
		<cl-message ref="message"/>
	    <view class="content-action">
			<cl-button type="success" size="small" icon='cl-icon-plus' @click="open('foods')">增选菜品</cl-button>
			<cl-button type="primary" size="small" icon='cl-icon-link' @click="updateFoodRank()">店长推荐</cl-button>
			<cl-button type="primary" size="small" icon='cl-icon-edit' @click="open('stock')">批量修改库存</cl-button>
			<cl-button type="error" size="small" icon='cl-icon-trash' @click="deleteStoreFood()">下架</cl-button>
	    </view>
		<scroll-view scroll-y class="content-box">
			<cl-grid>
				<cl-grid-item isTitle width="5%">
					<cl-checkbox label="true" @change="checked"></cl-checkbox>
				</cl-grid-item>
			    <cl-grid-item isTitle width="7%">主图</cl-grid-item>
				<cl-grid-item isTitle width="15%">菜品名称</cl-grid-item>
				<cl-grid-item isTitle width="12%">动销指数(DSI)</cl-grid-item>
				<cl-grid-item isTitle width="11%">归属分类</cl-grid-item>
				<cl-grid-item isTitle width="6%">累计售出</cl-grid-item>
				<cl-grid-item isTitle width="10%">零售价</cl-grid-item>
				<cl-grid-item isTitle width="14%">剩余库存</cl-grid-item>
				<cl-grid-item isTitle width="20%">操作</cl-grid-item>
			</cl-grid>
			<scroll-view scroll-y class="content-box-content">
				<cl-grid border>
					<block v-for="(food,index) in data.foods" :key="index">
						<cl-grid-item width="5%">
							<cl-checkbox v-model="food.Checked" label="true"></cl-checkbox>
						</cl-grid-item>
						<cl-grid-item width="7%">
							<image :src="food.Image_Url" mode=""></image>
						</cl-grid-item>
						<cl-grid-item width="15%">
						    <text>{{food.Title}}</text>
						</cl-grid-item>
						<cl-grid-item width="12%">
							<cl-health disabled icon="cl-icon-emoji" :value="Dsi(food)" v-if="Dsi(food) >= 0"></cl-health>
							<cl-health disabled icon="cl-icon-anger" :value="Dsi(food)" :color="['#F56C6C']" v-else></cl-health>
						</cl-grid-item>
						<cl-grid-item width="11%">{{getCut(food.Cut)}}</cl-grid-item>
						<cl-grid-item width="6%">{{food.Sell}}</cl-grid-item>
						<cl-grid-item width="10%">{{food.Price|toMoney(2)}}元</cl-grid-item>
						<cl-grid-item width="14%">
						    <cl-progress :ready="food.Ready" :stock="food.Stock" :color="colorList"></cl-progress>
						</cl-grid-item>
						<cl-grid-item width="20%">
							<cl-button size="mini" icon='cl-icon-edit' @click="open('stock',food)">库存</cl-button>
							<cl-button size="mini" icon='cl-icon-close' @click="deleteStoreFood(food)">下架</cl-button>
							<cl-button size="mini" icon='cl-icon-close' @click="updateFoodRank(food)" v-if="food.Rank">推荐</cl-button>
						</cl-grid-item>
					</block>
				</cl-grid>
			</scroll-view>
		</scroll-view>
		<!-- 库存调整 -->
		<cl-popup v-if="popup.stock.windows" :visible.sync="popup.stock.windows" kuan="35%" direction="left" class="content-popop">
			<cl-grid border v-if="popup.stock.data.length > 0">
			    <cl-grid-item isTitle width="50%">修改库存</cl-grid-item>
			    <cl-grid-item isTitle width="15%" center></cl-grid-item>
			    <cl-grid-item isTitle width="20%" center></cl-grid-item>
			    <cl-grid-item isTitle width="15%" center></cl-grid-item>
			    <block v-for="food in popup.stock.data" :key="food.Id">
				    <cl-grid-item width="50%">{{food.Title}}</cl-grid-item>
					<cl-grid-item width="15%" center>
						<cl-button type="primary" size="mini" @click="food.Ready--">减</cl-button>
					</cl-grid-item>
					<cl-grid-item width="20%" center>
					    <cl-input type="number" grid :border="false" v-model="food.Ready"></cl-input>
					</cl-grid-item>
					<cl-grid-item width="15%" center>
						<cl-button type="primary" size="mini" @click="food.Ready++">增</cl-button>
					</cl-grid-item>
			    </block>
			</cl-grid>
			<cl-list justify="start" v-else>请勾选需要编辑库存的菜品</cl-list>
			<cl-list justify="start">库存数据可直接输入编辑,数据更新后库存会回置100%状态</cl-list>
			<cl-list justify="start" v-if="popup.stock.data.length > 0">
			   <cl-button type="primary" @click="updateReady()">提交保存</cl-button>
			</cl-list>
		</cl-popup>
		<!-- 库存调整 -->
		<!-- 选择菜品 -->
		<cl-popup v-if="popup.foods.windows" :visible.sync="popup.foods.windows" kuan="50%" direction="left" class="content-popop">
			<cl-list label="菜品分类" justify="start">
			    <cl-select v-model="popup.foods.choose" :options="getCutSelect(false)" @change="cutChange"></cl-select>
			</cl-list>
			<cl-grid border>
			    <cl-grid-item isTitle width="15%">主图</cl-grid-item>
			    <cl-grid-item isTitle width="25%">名称</cl-grid-item>
			    <cl-grid-item isTitle width="15%">经营门店数</cl-grid-item>
				<cl-grid-item isTitle width="15%">历史售出</cl-grid-item>
			    <cl-grid-item isTitle width="30%">操作</cl-grid-item>
			    <block v-for="food in popup.foods.data" :key="food.Id">
				    <cl-grid-item width="15%">
						<image :src="food.Image_Url" mode=""></image>
					</cl-grid-item>
				    <cl-grid-item width="25%">{{food.Title}}</cl-grid-item>
				    <cl-grid-item width="15%">{{food.Count}}</cl-grid-item>
					<cl-grid-item width="15%">{{food.AllSell ? food.AllSell : 0}}份</cl-grid-item>
				    <cl-grid-item width="30%">
						<cl-button size="mini" icon='cl-icon-piechart_1'>分析</cl-button>
						<cl-button type="primary" size="mini" icon='cl-icon-plus' v-if="!checkHave(food)" @click="toMyStore(food)">经营</cl-button>
					</cl-grid-item>
			    </block>
			</cl-grid>
			<Page :length="popup.foods.data.length" :max="10" @change="turnPage"></Page>
		</cl-popup>
		<!-- 选择菜品 -->
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	import Time from '@/components/Time'
	import Page from '@/components/Page'
	export default {
		components: {
			Time,Page
		},
		props: {
			menuId:null
		},
		data() {
			return {
				popup:{
					store:{
						windows: false,
						choose: 0,
						data: []
					},
					foods: {
						windows: false,
						choose: 0,
						data: [],
						page: 1
					},
					stock:{
						windows: false,
						data: null
					}
				},
				data:{
					foods: [],
					cut: [],
				}
			}
		},
		computed: {
			...mapState(['hasLogin','role','userInfo','store']),
			getCut(){
				return function(cut){
					return cut==0 ? '-' : this.data.cut[this.data.cut.findIndex(item=>item.Id==cut)].Title
				}
			},
			Dsi(){
				return function(food){
					let day = (new Date().getTime() / 1000 - food.Time) / 86400
					if(day <= 7){
						return 0
					}
					let index = (day - 7) / (food.Sell - 1) / day
					index = index > 0 ? 100 - index * 10000 : index * 100
					return Math.floor(index)
				}
			},
			getCutSelect(){
				return function(is){
					let res = is == true ? [{label: '根类目', value: 0}] : []
					let root = is == true ? this.data.cut.filter(item=>item.Cut===0) : this.data.cut.filter(item=>item.Cut > 0)
					root.forEach(item=>{
						res.push({label: item.Title, value: item.Id})
					})
					return res
				}
			},
			checkHave(){
				return function(food){
					return this.data.foods.findIndex(item=>item.Id==food.Id) > -1 ? true : false
				}
			},
			choose(){
				return this.store.choose
			}
		},
		created(){
			if(this.hasLogin){
				this.$socket.sendMessage({action: 'GetFoodsCut', menu: this.menuId, token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetMyFoods', store: this.store.choose, menu: this.menuId, token: this.userInfo.Token},this)
			}
		},
		watch: {
			choose(newData,oldData){
				this.$socket.sendMessage({action: 'GetMyFoods', store: newData, menu: this.menuId, token: this.userInfo.Token},this)
			}
		},
		methods:{
			updateReady(){
				let index
				this.$socket.sendMessage({action: 'updateReady', form: this.popup.stock.data, store: this.store.choose, menu: this.menuId, token: this.userInfo.Token},this)
				this.popup.stock.data.forEach(item=>{
					index = this.data.foods.findIndex(food=>food.Id === item.Id)
					if(index > -1){
						this.$set(this.data.foods[index],'Ready',item.Ready)
						this.$set(this.data.foods[index],'Stock',item.Ready)
					}
				})
			},
			open(e,data = null){
				this.popup[e].data = null
				this.popup[e].windows = true
				switch(e){
					case 'stock':
					    if(data){
							this.popup[e].data = []
							this.popup[e].data.push(data)
						}else{
							this.popup[e].data = this.data.foods.filter(food=>food.Checked==true)
						}
					break
					case 'foods':
					    this.popup[e].data = []
						let select = this.getCutSelect(false)
						if(select.length > 0){
							this.popup[e].choose = select[0].value
							this.cutChange(select[0].value)
						}
					break
				}
			},
			checked(check){
				this.data.foods.forEach((item,index)=>{
					this.$set(this.data.foods[index],'Checked',check)
				})
			},
			onMessage(res){
				let index = null
				switch (res.action) {
					case 'GetMyFoods':
						this.data.foods = res.data
					break
					case 'GetFoodsCut':
					    this.data.cut = res.data
					break
					case 'updateReady':
					    this.popup.stock.windows = false
						index = this.data.foods.findIndex(food=>food.Id == res.data.Id && food.Store_Id == res.data.Store_Id)
						if(index > -1){
							this.$set(this.data.foods[index],'Ready',res.data.Ready)
							this.$set(this.data.foods[index],'Stock',res.data.Ready)
							this.$refs["message"].open({
							    message: res.msg,
							    type: 'info'
							})
						}
					break
					case 'GetFoodsByCut':
					    this.popup.foods.data = res.data
					break
					case 'toMyStore':
					    //this.popup.foods.windows = false
					    if(res.data.store == this.store.choose){
						    this.data.foods.push(res.data.food)
							this.$refs["message"].open({
							    message: res.msg,
							    type: 'info'
							})
					    }
					break
					case 'deleteStoreFood':
					    index = this.data.foods.findIndex(food=>food.Id == res.data.Id && food.Store_Id == res.data.Store_Id)
						if(index > -1){
							this.data.foods.splice(index,1)
							this.$refs["message"].open({
							    message: res.msg,
							    type: 'info'
							})
						}
					break
					case 'updateFoodRank':
					    index = this.data.foods.findIndex(food=>food.Id == res.data.Id && food.Store_Id == res.data.Store_Id)
					    if(index > -1){
					    	this.$set(this.data.foods[index],'Rank',this.data.foods[index].Rank==0 ? 1:0)
					    	this.$refs["message"].open({
					    	    message: res.msg,
					    	    type: 'info'
					    	})
					    }
					break
				}
			},
			cutChange(cut){
				this.$socket.sendMessage({action: 'GetFoodsByCut', store: this.store.choose, page: this.popup.foods.page, cut: cut, menu: this.menuId, token: this.userInfo.Token},this)
			},
			toMyStore(food){
				this.$socket.sendMessage({action: 'toMyStore', store: this.store.choose, food: food, menu: this.menuId, token: this.userInfo.Token},this)
			},
			deleteStoreFood(food){
				if(food){
					this.$socket.sendMessage({action: 'deleteStoreFood', store: this.store.choose, foods: [food], menu: this.menuId, token: this.userInfo.Token},this)
				}else{
					const foods = this.data.foods.filter(food=>food.Checked==true)
					this.$socket.sendMessage({action: 'deleteStoreFood', store: this.store.choose, foods: foods, menu: this.menuId, token: this.userInfo.Token},this)
				}
			},
			updateFoodRank(food){
				if(food){
					this.$socket.sendMessage({action: 'updateFoodRank', store: this.store.choose, foods: [food], menu: this.menuId, token: this.userInfo.Token},this)
				}else{
					const foods = this.data.foods.filter(food=>food.Checked==true)
					this.$socket.sendMessage({action: 'updateFoodRank', store: this.store.choose, foods: foods, menu: this.menuId, token: this.userInfo.Token},this)
				}
			}
		}
	}
</script>

<style lang="scss">
	.content{
		font-size: 13px;
		overflow: hidden;
		width: calc(100% - 40px);
		height: calc(100% - 30px);
		padding: 10px;
		margin: 0 10px 10px;
		background: #fff;
		&-popop{
			overflow: hidden;
			&-list{
				margin-right: 10px;
			}
			&-button{
				width: 150px;
			}
			&-title{
				margin-bottom: 20px;
			}
			&-line{
				display: grid;
				grid-template-columns: 15% 85%;
				margin: 15px 0;
				line-height: 35px;
				width: 100%;
				overflow: hidden;
				&-name{
					overflow: hidden;
				}
				&-content{
					padding: 0 5px 2px 0;
					text-align: center;
				}
			}
		}
		&-action{
			overflow: hidden;
			padding: 0 0 10px;
			height: 30px;
			display: flex;
			> *{
				margin-right: 10rpx;
			}
		}
		&-box{
			height: calc(100% - 40px);
			overflow: hidden;
			&-content{
				height: calc(100% - 50px);
				overflow: hidden;
			}
		}
	}
</style>