<template>
	<view class="content">
		<cl-message ref="message"/>
		<cl-popup :visible.sync="visible" gao="480px" kuan="560px" direction="center" class="content-popop">
			<view class="content-popop-title">基本信息</view>
		    <cl-input class="content-popop-line" prefix-icon='cl-icon-type' v-model="form.Name" placeholder="菜单名称"></cl-input>
			<cl-input class="content-popop-line" prefix-icon='cl-icon-link' v-model="form.Page" placeholder="组件位置"></cl-input>
			<view class="content-popop-line">菜单权限</view>
			<view class="content-popop-line">
				<cl-checkbox-group v-model="form.Role">
					<block v-for="item in role" :key="item.Id">
						<cl-checkbox :label="item.Id" :disabled="editMode==0">{{item.Name}}</cl-checkbox>
					</block>
				</cl-checkbox-group>
			</view>
			<view class="content-popop-line">菜单图标</view>
			<view class="content-popop-line">
				<cl-upload v-model="form.Icon" :size="['100px', '100px']" :limit="1"></cl-upload>
			</view>
			<view class="content-popop-button">
				<cl-button type="default" size="mini" @click="visible=false">关闭</cl-button>
				<cl-button type="primary" size="mini" @click="Menu()">提交</cl-button>
			</view>
		</cl-popup>
	    <view class="content-action">
			<cl-button type="default" size="mini" @click="getMenu()">刷新</cl-button>
	    	<cl-button type="primary" size="mini" @click="addMenu()">新增</cl-button>
	    </view>
		<view class="content-box">
			<cl-grid  class="content-box-head">
			    <cl-grid-item width="20%">名称</cl-grid-item>
				<cl-grid-item width="20%">图标</cl-grid-item>
				<cl-grid-item width="20%">组件</cl-grid-item>
				<cl-grid-item width="20%">权限角色</cl-grid-item>
				<cl-grid-item width="20%">操作</cl-grid-item>
			</cl-grid>
			<scroll-view scroll-y class="content-box-content">
				<cl-grid border class="content-box-line">
					<block v-for="item in getRootMenu" :key="item.Id">
						<cl-grid-item width="20%">{{item.Name}}</cl-grid-item>
						<cl-grid-item width="20%">
							<image class="content-box-icon" :src="item.Icon"></image>
						</cl-grid-item>
						<cl-grid-item width="20%">{{item.Page ? item.Page : '-'}}</cl-grid-item>
						<cl-grid-item width="20%">{{getRole(item.Role)}}</cl-grid-item>
						<cl-grid-item width="20%">
							<cl-button size="mini" icon='cl-icon-edit' @click="addMenu(item.Id)" v-if="!item.Page">新增</cl-button>
							<cl-button size="mini" icon='cl-icon-edit' @click="editMenu(item)">编辑</cl-button>
							<cl-button size="mini" icon='cl-icon-close' @click="deleteMenu(item.Id)">删除</cl-button>
						</cl-grid-item>
						<block v-for="child in item.child" :key="child.Id">
							<cl-grid-item width="20%" class="content-box-child">{{child.Name}}</cl-grid-item>
							<cl-grid-item width="20%">-</cl-grid-item>
							<cl-grid-item width="20%">{{child.Page ? child.Page : '-'}}</cl-grid-item>
							<cl-grid-item width="20%">{{getRole(child.Role)}}</cl-grid-item>
							<cl-grid-item width="20%">
								<cl-button size="mini" icon='cl-icon-edit' @click="editMenu(child)">编辑</cl-button>
								<cl-button size="mini" icon='cl-icon-close' @click="deleteMenu(child.Id)">删除</cl-button>
							</cl-grid-item>
						</block>
					</block>
				</cl-grid>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	export default {
		props: {
			menuId:null
		},
		data() {
			return {
				editMode: 0, //编辑模式 0 根目录 1 组件
				visible: false,
				form: {Mode:null,Cut:null,Name:null,Icon:null,Page:null,Role:[],Menu:null}
			}
		},
		computed: {
			...mapState(['hasLogin','menu','role','userInfo']),
			getRootMenu(){
				let root = this.menu.filter(menu=>menu.Cut===0)
				root.forEach(item=>{
					item.child = this.menu.filter(menu=>menu.Cut===item.Id)
				})
				return root
			},
			getRole(){
				return function(role){
					if(role == 0){
						return '-'
					}else{
						let result = ''
						let that = role.split(",")
						that.forEach(m=>{
							let index = this.role.findIndex(n=>n.Id == m)
							result = result + ' ' + this.role[index].Name
						})
						return result
					}
				}
			}
		},
		created(){
			if(this.hasLogin){
				this.$socket.sendMessage({action: 'GetCosKey', token: this.userInfo.Token},this)
			}
		},
		methods:{
			//信息接收
			onMessage(res){
				switch (res.action) {
					case 'Menu':
					    this.visible = false
						this.form = {Mode:null,Cut:null,Name:null,Icon:null,Page:null,Role:[]}
						this.$refs["message"].open({
						    message: res.data,
							type: 'success_no_circle'
						})
					break
				}
			},
			//提交保存
			Menu(){
				//判断名称是否输入
				if(!this.form.Name){
					this.$refs["message"].open({
					    message: "请输入菜单名称",
						type: "warn"
					})
					return
				}
				//判断组件是否已经定义
				if(this.form.Cut>0 && !this.form.Page){
					this.$refs["message"].open({
					    message: "请输入组件页面地址",
						type: "warn"
					})
					return
				}
				this.$socket.sendMessage({action: 'Menu', form: this.form, menu: this.menuId, token: this.userInfo.Token},this)
			},
			//刷新菜单
			getMenu(){
				if(this.hasLogin){
					this.$socket.sendMessage({action: 'GetMenu', token: this.userInfo.Token},this)
				}
			},
			//新增
			addMenu(e){
				this.visible = true
				this.editMode = e ? 1 : 0
				this.form = {Mode: 0, Cut: e ? e : 0, Name: null, Icon: '', Page: null, Role: []}
			},
			//编辑
			editMenu(e){
				console.log(e)
				this.visible = true
				this.editMode = e.Page ? 1 : 0
				this.form = {Mode: 1, Cut: e.Cut, Name: e.Name, Icon: e.Icon, Page: e.Page ? e.Page : null, Role: e.Role.split(","), Menu:e.Id}
			},
			//删除菜单
			deleteMenu(menu){
				if(this.hasLogin){
					this.$socket.sendMessage({action: 'deleteMenu', menu: this.menuId, id: menu, token: this.userInfo.Token},this)
				}
			}
		}
	}
</script>

<style lang="scss">
	.content{
		overflow: hidden;
		width: calc(100% - 40px);
		height: calc(100% - 30px);
		padding: 10px;
		margin: 0 10px 10px;
		background: #fff;
		&-popop{
			&-title{
				margin-bottom: 20px;
			}
			&-line{
				margin: 20px 0;
			}
			&-button{
				margin: 10px 0;
			}
		}
		&-action{
			overflow: hidden;
			height: 40px;
		}
		&-box{
			height: calc(100% - 40px);
			overflow: hidden;
			&-content{
				height: calc(100% - 50px);
				overflow: hidden;
			}
			&-icon{
				width: 20px;
				height: 20px;
				vertical-align: middle;
				background-color: #2f3447;
			}
			&-action{
				color: #4165d7;
				margin-right: 10px;
				cursor: pointer;
			}
			&-child{
				padding-left: 25px;
			}
			&-head{
				background-color: #ebeef5;
				overflow: hidden;
			}
		}
	}
</style>
