<template>
	<view class="content">
	    <cl-message ref="message"/>
		<scroll-view scroll-y class="content-box">
			<view class="content-box-edit" v-if="info">
				<view>
					<cl-list label="操作门店:" justify="start">
						<cl-select placeholder="切换门店" v-model="store.choose" :options="getStore" @change="storeChange"></cl-select>
					</cl-list>
					<cl-list justify="start" disabled>
						<text>该电话号码用于店铺资料展示与用户联系使用，请确保该号码可以随时被拨通，如在营业期间被多次投诉无人接听将被总部进行处罚！</text>
					</cl-list>
					<cl-list label="主页电话:" justify="start">
						<cl-input disabled v-model="info.Phone" placeholder="显示在APP上的电话号码">
							<cl-button size="mini" slot="append" type="primary" @click="getStoreNumber(store.choose)">选择员工</cl-button>
						</cl-input>
					</cl-list>
					<cl-list justify="start" disabled>
						<text>默认店铺营业时间为24小时，请根据自身的经营能力进行调整，建议营业时间为上午10:00-深夜2:00</text>
					</cl-list>
					<cl-list label="营业时间:" justify="right">
						<cl-select placeholder="开始营业时间" v-model="info.Sell_Time_Start" :options="timeOptions"></cl-select>
						<cl-select placeholder="结束营业时间" v-model="info.Sell_Time_End" :options="timeOptions"></cl-select>
						<cl-button type="primary" size="small" @click="saveSellTime(store.choose)">保存</cl-button>
					</cl-list>
					<cl-list justify="start" disabled>
						<text>只有店铺处于正常营业状态才能进行接单，非营业状态下店铺不在APP上进行展示，过多调休将影响接单优先指数</text>
					</cl-list>
					<cl-list label="营业状态:" justify="start">
						<cl-select placeholder="切换营业状态" v-model="info.Status" :options="status" @change="statusChange"></cl-select>
					</cl-list>
					<cl-list justify="start" disabled>
						<text>这是显示在店铺首页顶部的背景图，推荐图片的尺寸比例为：，请勿上传杂乱图像与涉嫌非法的图片，否则不仅无法通过审核还将被关闭图片定义的权限！</text>
					</cl-list>
					<cl-list label="背景图片:" justify="start">
					    <cl-upload v-model="info.Url" :size="['150px', '100%']" :limit="1"></cl-upload>
					</cl-list>
					<cl-list justify="start" disabled>
						<text>不同星级门店拥有不同数量的可用推荐位用于首页展示，默认每个店铺拥有4个推荐位，以下是您对应推荐位的占用情况.</text>
					</cl-list>
					<cl-list justify="start">
					   <cl-grid border style="width: 100%;">
					        <cl-grid-item isTitle width="10%">推荐位</cl-grid-item>
					   	    <cl-grid-item isTitle width="15%">菜品主图</cl-grid-item>
					   	    <cl-grid-item isTitle width="35%">菜品名称</cl-grid-item>
							<cl-grid-item isTitle width="20%">累计售出</cl-grid-item>
							<cl-grid-item isTitle width="20%">上架时间</cl-grid-item>
							<block v-for="(item,index) in info.Ads" :key="item.Id">
								<cl-grid-item width="10%">{{index+1}}</cl-grid-item>
								<cl-grid-item width="15%">
									<image :src="item.Image_Url" mode=""></image>
								</cl-grid-item>
								<cl-grid-item width="35%">{{item.Title}}</cl-grid-item>
								<cl-grid-item width="20%">{{item.Sell}}</cl-grid-item>
								<cl-grid-item width="20%">{{item.Time|forDate}}</cl-grid-item>
							</block>
					   </cl-grid>
					</cl-list>
				</view>
				<view>
					
				</view>
			</view>
		</scroll-view>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	import Time from '@/components/Time'
	export default {
		components: {
			Time
		},
		props: {
			menuId:null
		},
		data() {
			return {
				store: {choose: 0, list: []},
				info: {Url: null},
				status: [
					{label: '停业关张', value: -1},
					{label: '正常营业', value: 0},
					{label: '临时休息', value: 1},
					{label: '停业整顿', value: 2},
					{label: '即将开业', value: 3},
					{label: '正在装修', value: 4},
					{label: '接受培训', value: 5}
				    ],
				timeOptions:[
					{label: '廿四小时营业', value: 0},
					{label: '早上6:00', value: 21600},
					{label: '早上7:00', value: 25200},
					{label: '早上8:00', value: 28800},
					{label: '上午9:00', value: 32400},
					{label: '上午10:00', value: 36000},
					{label: '上午11:00', value: 39600},
					{label: '中午12:00', value: 43200},
					{label: '中午13:00', value: 46800},
					{label: '中午14:00', value: 50400},
					{label: '下午15:00', value: 54000},
					{label: '下午16:00', value: 57600},
					{label: '下午17:00', value: 61200},
					{label: '下午18:00', value: 64800},
					{label: '晚上19:00', value: 68400},
					{label: '晚上20:00', value: 72000},
					{label: '晚上21:00', value: 75600},
					{label: '晚上22:00', value: 79200},
					{label: '深夜23:00', value: 82800},
					{label: '深夜0:00', value: 86400},
					{label: '深夜1:00', value: 3600},
					{label: '深夜2:00', value: 7200},
					{label: '凌晨3:00', value: 10800},
					{label: '凌晨4:00', value: 14400},
					{label: '凌晨5:00', value: 18000}
					],
			}
		},
		computed: {
			...mapState(['hasLogin','role','userInfo']),
			getStore(){
				let store = []
				this.store.list.forEach(item=>{
					store.push({label: item.Name, value: item.Id})
				})
				return store
			},
			urlChange(){
				return this.info.Url ? this.info.Url : null
			}
		},
		watch:{
			urlChange(newData,oldData){
				if(newData){
					this.$socket.sendMessage({action: 'updateStoreUrl', store: this.store.choose, url: newData, menu: this.menuId, token: this.userInfo.Token},this)
				}
			}
		},
		created(){
			if(this.hasLogin){
				this.$socket.sendMessage({action: 'GetCosKey', token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetMyStore', menu: this.menuId, token: this.userInfo.Token},this)
			}
		},
		methods:{
			statusChange(status){
				this.$socket.sendMessage({action: 'updateStoreStatus', store: this.store.choose, status: status, menu: this.menuId, token: this.userInfo.Token},this)
			},
			getStoreNumber(store){
				this.$socket.sendMessage({action: 'getStoreNumber', store: store, menu: this.menuId, token: this.userInfo.Token},this)
			},
			saveSellTime(store){
				this.$socket.sendMessage({action: 'saveSellTime', store: store, time: {start: this.info.Sell_Time_Start ,end: this.info.Sell_Time_End}, menu: this.menuId, token: this.userInfo.Token},this)
			},
			storeChange(store){
				this.$socket.sendMessage({action: 'getStoreInfo', store: store, menu: this.menuId, token: this.userInfo.Token},this)
			},
			//信息接收
			onMessage(res){
				const that = this
				let index = null
				let itemList = []
				switch (res.action) {
					case 'GetMyStore':
					    this.$set(this.store,'list',res.data)
						if(res.data.length > 0){
							this.$set(this.store,'choose',res.data[0].Id)
							this.storeChange(res.data[0].Id)
						}
					break
					case 'getStoreInfo':
					    this.info = res.data
					break
					case 'getStoreNumber':
						res.data.forEach(item=>{
							itemList.push(item.Name)
						})
						uni.showActionSheet({
						    itemList: itemList,
						    success: function (number) {
								that.info.Phone = res.data[number.tapIndex].UserName
								that.$socket.sendMessage({action: 'updateStorePhone', store: that.store.choose, number: res.data[number.tapIndex], menu: that.menuId, token: that.userInfo.Token},that)
							}
						})
					break
				}
			}
		}
	}
</script>

<style lang="scss">
	.content{
		overflow: hidden;
		width: calc(100% - 40rpx);
		height: calc(100% - 30rpx);
		padding: 10rpx;
		margin: 0 10rpx 10rpx;
		background: #fff;
		border-radius: 10rpx;
		&-open{
			padding: 0 0 10px;
			height: 30px;
			display: flex;
		}
		&-box{
			height: 100%;
			overflow: hidden;
			&-edit{
				height: 100%;
				display: grid;
				grid-template-columns: 50% 50%;
			}
		}
	}
</style>