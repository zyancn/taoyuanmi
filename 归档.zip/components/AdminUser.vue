<template>
	<view class="content">
		<cl-message ref="message"/>
		<cl-popup :visible.sync="visible" gao="230px" kuan="300px" direction="center" class="content-popop">
			<view class="content-popop-title">增加角色</view>
		    <cl-input class="content-popop-line" prefix-icon='cl-icon-friends_add' v-model="form.Name" placeholder="角色称呼"></cl-input>
			<cl-input class="content-popop-line" prefix-icon='cl-icon-link' v-model="form.Page" placeholder="首页组件"></cl-input>
			<view class="content-popop-button">
				<cl-button type="default" size="mini" @click="visible=false">关闭</cl-button>
				<cl-button type="primary" size="mini" @click="Role()">保存</cl-button>
			</view>
		</cl-popup>
	    <view class="content-action">
	    	<cl-button type="primary" size="mini" @click="addRole()">增加角色</cl-button>
	    </view>
		<scroll-view scroll-y class="content-box">
			<cl-grid :column="3" class="content-box-line content-box-head">
			    <cl-grid-item width="20%">角色称呼</cl-grid-item>
				<cl-grid-item width="50%">首页模型</cl-grid-item>
				<cl-grid-item width="30%">操作</cl-grid-item>
			</cl-grid>
			<scroll-view scroll-y class="content-box-content">
				<cl-grid :column="3" border class="content-box-line">
					<block v-for="item in role" :key="item.Id">
						<cl-grid-item width="20%">{{item.Name}}</cl-grid-item>
						<cl-grid-item width="50%">{{item.Page ? item.Page : '-'}}</cl-grid-item>
						<cl-grid-item width="30%">
							<text class="content-box-line-item-action" @click="editRole(item)">编辑</text>
							<text class="content-box-line-item-action" @click="deleteRole(item.Id)">删除</text>
						</cl-grid-item>
					</block>
				</cl-grid>
			</scroll-view>
		</scroll-view>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	export default {
		props: {
			menuId:null
		},
		data() {
			return {
				visible: false,
				form: {Id: null, Name: null, Page: null}
			}
		},
		computed: {
			...mapState(['hasLogin','role','userInfo'])
		},
		methods:{
			//信息接收
			onMessage(res){
				switch (res.action) {
					case 'Role':
					    this.visible = false
						this.form = {Id: null, Name: null, Page: null}
						this.$refs["message"].open({
						    message: res.data,
							type: 'success_no_circle'
						})
					break
				}
			},
			//提交保存
			Role(){
				//判断名称是否输入
				if(!this.form.Name){
					this.$refs["message"].open({
					    message: "请输入菜单名称",
						type: "warn"
					})
					return
				}
				//判断组件是否已经定义
				if(this.form.Cut>0 && !this.form.Page){
					this.$refs["message"].open({
					    message: "请输入组件页面地址",
						type: "warn"
					})
					return
				}
				this.$socket.sendMessage({action: 'Role', form: this.form, menu: this.menuId, token: this.userInfo.Token},this)
			},
			//新增
			addRole(e){
				this.visible = true
				this.form = {Id: null, Name: null, Page: null}
			},
			//编辑
			editRole(e){
				this.visible = true
				this.form = {Id: e.Id, Name: e.Name, Page: e.Page}
			},
			//删除菜单
			deleteRole(role){
				if(this.hasLogin){
					this.$socket.sendMessage({action: 'deleteRole', menu: this.menuId, id: role, token: this.userInfo.Token},this)
				}
			}
		}
	}
</script>

<style lang="scss">
	.content{
		overflow: hidden;
		width: calc(100% - 40px);
		height: calc(100% - 30px);
		padding: 10px;
		margin: 0 10px 10px;
		background: #fff;
		&-popop{
			&-title{
				margin-bottom: 20px;
			}
			&-line{
				margin: 20px 0;
			}
			&-button{
				margin: 10px 0;
			}
		}
		&-action{
			overflow: hidden;
			height: 40px;
		}
		&-box{
			height: calc(100% - 40px);
			overflow: hidden;
			&-content{
				height: calc(100% - 35px);
			}
			&-line{
				line-height: 35px;
				&-item{
					padding-left: 10px;
					&-icon{
						width: 20px;
						height: 20px;
						vertical-align: middle;
						background-color: #2f3447;
					}
					&-action{
						color: #4165d7;
						margin-right: 10px;
						cursor: pointer;
					}
				}
				&-child{
					padding-left: 25px;
				}
			}
			&-head{
				background-color: #ebeef5;
			}
		}
	}
</style>