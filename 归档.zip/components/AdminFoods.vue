<template>
	<view class="content">
		<cl-message ref="message"/>
		<!-- 新增/编辑分类 -->
		<cl-popup :visible.sync="visible.cut" kuan="550px" direction="left" class="content-popop">
			<view class="content-popop-title" style="display: flex;">
				<cl-button type="warn" size="mini" @click="action('addcut')">新增分类</cl-button>
			</view>
			<cl-grid :column="4">
			    <cl-grid-item width="35%" isTitle>名称</cl-grid-item>
				<cl-grid-item width="20%" isTitle>创建时间</cl-grid-item>
				<cl-grid-item width="20%" isTitle>创建人</cl-grid-item>
				<cl-grid-item width="25%" isTitle>操作</cl-grid-item>
				<block v-for="item in getFcut()" :key="item.Id">
					<cl-grid-item width="35%">{{item.Title}}</cl-grid-item>
					<cl-grid-item width="20%">{{item.Create_Time|forDate}}</cl-grid-item>
					<cl-grid-item width="20%">{{item.User}}</cl-grid-item>
					<cl-grid-item width="25%">
						<text class="content-box-action" @click="deleteFoodsCut(item.Id)">删除分类</text>
					</cl-grid-item>
					<block v-for="child in item.child" :key="child.Id">
						<cl-grid-item width="35%" style="padding-left: 30px;">{{child.Title}} ({{child.Count}})</cl-grid-item>
						<cl-grid-item width="20%">{{child.Create_Time|forDate}}</cl-grid-item>
						<cl-grid-item width="20%">{{child.User}}</cl-grid-item>
						<cl-grid-item width="25%">
							<text class="content-box-action" @click="deleteFoodsCut(child.Id)">删除分类</text>
						</cl-grid-item>
					</block>
				</block>
			</cl-grid>
		</cl-popup>
		<!-- 商品分类编辑 -->
		<cl-popup :visible.sync="visible.addcut" gao="200px" kuan="300px" direction="center" class="content-popop" v-if="form.addcut">
			<cl-list label="类目名称" justify="start">
			    <cl-input v-model="form.addcut.Title" placeholder="类目名称"></cl-input>
			</cl-list>
			<cl-list label="类目归属" justify="center">
			    <cl-select v-model="form.addcut.Cut" :options="getCutSelect(true)"></cl-select>
			</cl-list>
			<cl-list justify="start">
				 <cl-button type="primary" @click="FoodsCut()" round>提交保存</cl-button>
			</cl-list>
		</cl-popup>
		<!-- 口味模板列表 -->
		<cl-popup :visible.sync="visible.choose" kuan="800px" direction="left" class="content-popop">
			<view class="content-popop-title" style="display: flex;">
				<cl-button type="warn" size="mini" @click="action('addchoose')">新增模板</cl-button>
			</view>
			<cl-grid :column="4" class="content-box-line content-box-head">
			    <cl-grid-item width="20%" isTitle>模板名称</cl-grid-item>
				<cl-grid-item width="35%" isTitle>口味选项</cl-grid-item>
				<cl-grid-item width="20%" isTitle>创建人</cl-grid-item>
				<cl-grid-item width="25%" isTitle>操作</cl-grid-item>
			</cl-grid>
			<cl-grid :column="4" border class="content-box-line">
				<block v-for="item in choose" :key="item.Id">
					<cl-grid-item width="20%">{{item.Name}}</cl-grid-item>
					<cl-grid-item width="35%">{{item.Tags}}</cl-grid-item>
					<cl-grid-item width="20%">{{item.User}}</cl-grid-item>
					<cl-grid-item width="25%">
						<text class="content-box-action" @click="action('addchoose',item)">修改</text>
						<text class="content-box-action" @click="deleteFoodsChoose(item.Id)">删除</text>
					</cl-grid-item>
				</block>
			</cl-grid>
		</cl-popup>
		<!-- 新增口味模板 -->
		<cl-popup :visible.sync="visible.addchoose" gao="190px" kuan="500px" direction="center" class="content-popop" v-if="form.addchoose">
			<cl-list label="模板名称" justify="start">
			    <cl-input v-model="form.addchoose.Name" placeholder="模板名称"></cl-input>
			</cl-list>
			<cl-list label="模板口味" justify="center">
			    <cl-input v-model="form.addchoose.Tags" placeholder="不辣,微辣,中辣,超辣"></cl-input>
			</cl-list>
			<cl-list justify="end">
				 <cl-button type="primary" @click="FoodsChoose()" round>保存模板</cl-button>
			</cl-list>
		</cl-popup>
		<!-- 新增/编辑菜品 -->
		<cl-popup :visible.sync="visible.add" kuan="500px" direction="right" class="content-popop" v-if="form.add">
			<cl-list justify="start">
				<cl-divider>
				    <view>
				        <text class="cl-icon-favor"></text>
				        <text>{{form.add.Title}}</text>
				    </view>
				</cl-divider>
			</cl-list>
			<cl-list label="营销功能" justify="start">
				<cl-checkbox class="content-popop-button" v-model="form.add.UseCoupon" label="1">代金券抵扣</cl-checkbox>
				<cl-checkbox class="content-popop-button" v-model="form.add.Cash" label="1">扫码红包</cl-checkbox>
			</cl-list>
			<cl-list label="菜品名称" justify="start">
			    <cl-input v-model="form.add.Title" placeholder="菜品名称"></cl-input>
			</cl-list>
			<cl-list label="商品主图" justify="start">
			    <cl-upload v-model="form.add.Image_Url" :size="['100px', '100px']" :limit="1"></cl-upload>
			</cl-list>
			<cl-list label="菜品净重" justify="start">
			    <cl-input type="number" v-model="form.add.Weight" placeholder="单份的质量"><text slot="append">克</text></cl-input>
			</cl-list>
			<cl-list label="菜品价格" justify="start">
			    <cl-input type="number" v-model="form.add.Price" placeholder="每份价格"><text slot="append">元</text></cl-input>
			</cl-list>
			<cl-list label="赠品编号" justify="start">
			    <cl-input type="number" v-model="form.add.Gift" placeholder="赠品的商品Id">></cl-input>
			</cl-list>
			<cl-list label="菜品分类" justify="start">
			    <cl-select v-model="form.add.Cut" :options="getCutSelect(false)"></cl-select>
			</cl-list>
			<cl-list label="口感模板" justify="start">
			    <cl-select v-model="form.add.Foods_Choose_Id" :options="getChooseSelect"></cl-select>
			</cl-list>
			<cl-list label="准营商圈" justify="start">
			    <cl-select v-model="form.add.Foods_Shop_Cut_Id" :options="getStoreSelect"></cl-select>
			</cl-list>
			<cl-list label="适销季节" justify="start">
			    <cl-select v-model="form.add.Season" :options="season"></cl-select>
			</cl-list>
			<cl-list label="商品描述" justify="start">
			    <cl-input v-model="form.add.Describe" placeholder="一句话描述 100字以内"></cl-input>
			</cl-list>
			<cl-list label="滚动图片" justify="start">
			    <cl-upload v-model="form.add.Image" :size="['90px', '160px']" multiple :limit="20"></cl-upload>
			</cl-list>
			<cl-list justify="start">
				<cl-divider>
				    <view>
				        <text class="cl-icon-favor"></text>
				    </view>
				</cl-divider>
			</cl-list>
			<cl-list justify="start">
				<cl-button type="primary" @click="Foods()">提交保存</cl-button>
			</cl-list>
		</cl-popup>
	    <view class="content-action">
	    	<cl-button type="primary" size="mini" @click="action('add')">增加菜品</cl-button>
			<cl-button type="default" size="mini" @click="action('choose')">口味模板</cl-button>
			<cl-button type="default" size="mini" @click="action('set')">套餐管理</cl-button>
			<cl-button type="default" size="mini" @click="action('cut')">菜品分类</cl-button>
	    </view>
		<scroll-view scroll-y class="content-box">
			<cl-grid>
			    <cl-grid-item isTitle width="5%">主图</cl-grid-item>
				<cl-grid-item isTitle width="15%">名称</cl-grid-item>
				<cl-grid-item isTitle width="10%">分类</cl-grid-item>
				<cl-grid-item isTitle width="10%">零售价</cl-grid-item>
				<cl-grid-item isTitle width="10%">适销季节</cl-grid-item>
				<cl-grid-item isTitle width="10%">扫码红包</cl-grid-item>
				<cl-grid-item isTitle width="15%">上架时间</cl-grid-item>
				<cl-grid-item isTitle width="25%">操作</cl-grid-item>
			</cl-grid>
			<scroll-view scroll-y class="content-box-content">
				<cl-grid :column="8" border class="content-box-line">
					<block v-for="food in list" :key="food.Id">
						<block v-if="food.Status < 900">
							<cl-grid-item width="5%">
								<image class="content-box-line-item-icon" :src="food.Image_Url" mode=""></image>
							</cl-grid-item>
							<cl-grid-item width="15%">{{food.Title}}</cl-grid-item>
							<cl-grid-item width="10%">{{getCut(food.Cut)}}</cl-grid-item>
							<cl-grid-item width="10%">{{food.Price|toMoney(2)}}元</cl-grid-item>
							<cl-grid-item width="10%">{{food.Season|getSeason}}</cl-grid-item>
							<cl-grid-item width="10%">{{food.Cash ? '有':'无'}}</cl-grid-item>
							<cl-grid-item width="15%">{{food.Create_Time|forDate}}</cl-grid-item>
							<cl-grid-item width="25%">
								<text class="content-box-action" @click="action('sell',food)">数据</text>
								<text class="content-box-action" @click="action('add',food)">编辑</text>
								<text class="content-box-action" v-if="food.Status == 0" @click="deleteFoods(food.Id,1)">下架</text>
								<text class="content-box-action" v-if="food.Status == 1" @click="deleteFoods(food.Id,0)">重新上架</text>
							    <text class="content-box-action" v-if="food.Status < 900" @click="deleteFoods(food.Id,900)">删除</text>
							</cl-grid-item>
						</block>
					</block>
				</cl-grid>
				<Page :length="list.length" :max="15" @change="turnPage"></Page>
			</scroll-view>
		</scroll-view>
	</view>
</template>

<script>
	import {mapState} from 'vuex'
	import Time from '@/components/Time'
	import Page from '@/components/Page'
	export default {
		components: {
			Time,Page
		},
		props: {
			menuId:null
		},
		data() {
			return {
				page: 1,
				visible: {cut: false, add: false, addchoose: false, task: false, choose: false, addcut: false},
				list: [],
				cut: [],
				his: [],
				choose: [],
				store: [],
				season: [
					{label: '全年', value: 0},
				    {label: '春季', value: 1},
				    {label: '夏季', value: 2},
				    {label: '秋季', value: 3},
				    {label: '冬季', value: 4},
				],
				form: {
					add: null,
					addcut: null,
					addchoose: null,
				}
			}
		},
		computed: {
			...mapState(['hasLogin','role','userInfo']),
			getCut(){
				return function(cut){
					return cut==0 ? '-' : this.cut[this.cut.findIndex(item=>item.Id==cut)].Title
				}
			},
			getFcut(){
				return function(){
					let root = this.cut.filter(item=>item.Cut===0)
					root.forEach(item=>{
						item.child = this.cut.filter(cut=>cut.Cut===item.Id)
					})
					return root
				}
			},
			getChooseSelect(){
				let res = []
				this.choose.forEach(item=>{
					res.push({label: item.Name, value: item.Id})
				})
				return res
			},
			getStoreSelect(){
				let res = [{label: '所有门店', value: 0}]
				this.store.forEach(item=>{
					res.push({label: item.Name, value: item.Id})
				})
				return res
			},
			getCutSelect(){
				return function(is){
					let res = is==true ? [{label: '根类目', value: 0}] : []
					let root = is==true ? this.cut.filter(item=>item.Cut===0) : this.cut.filter(item=>item.Cut > 0)
					root.forEach(item=>{
						res.push({label: item.Title, value: item.Id})
					})
					return res
				}
			}
		},
		created(){
			if(this.hasLogin){
				this.$socket.sendMessage({action: 'GetCosKey', token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetFoodsChoose', menu: this.menuId, token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetFoodsCut', menu: this.menuId, token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetFoodsList', menu: this.menuId, page: this.page, token: this.userInfo.Token},this)
				this.$socket.sendMessage({action: 'GetStoreCut', menu: this.menuId, token: this.userInfo.Token},this)
			}
		},
		methods:{
			turnPage(page){
				this.list = []
				this.$socket.sendMessage({action: 'GetFoodsList', menu: this.menuId, page: page, token: this.userInfo.Token},this)
			},
			//信息接收
			onMessage(res){
				let index = null
				switch (res.action) {
					case 'GetStoreCut':
					    this.store = res.data
					break
					case 'GetFoodsList':
					    this.list = res.data
					break
					case 'GetFoodsCut':
					    this.cut = res.data
					break
					case 'GetFoodsChoose':
					    this.choose = res.data
					break
					case 'Foods':
					    this.visible.add = false
						index = this.list.findIndex(item=>item.Id == res.data.Id)
						if(index == -1){
							this.list.push(res.data)
						}else{
							this.list[index] = res.data
						}
					break
					case 'deleteFoods':
					    this.$refs["message"].open({
						    message: "已处理完毕",
							type: 'success_no_circle'
						})
					    this.list[this.list.findIndex(item=>item.Id == res.data.Id)].Status = res.data.Status
					break
					case 'ItemHis':
					    this.his = res.data
					break
					case 'FoodsCut':
					    this.cut = res.data
						this.visible.addcut = false
					break
					case 'deleteFoodsCut':
					    index = this.cut.findIndex(item=>item.Id==res.data)
						this.cut.splice(index,1)
						this.$refs["message"].open({
						    message: "删除成功",
							type: 'success_no_circle'
						})
					break
					case 'FoodsChoose':
					    this.visible.addchoose = false
					    this.$refs["message"].open({
					        message: res.data,
					    	type: 'success_no_circle'
					    })
					break
					case 'deleteFoodsChoose':
					    index = this.choose.findIndex(item=>item.Id==res.data)
					    this.choose.splice(index,1)
					    this.$refs["message"].open({
					        message: "删除成功",
					    	type: 'success_no_circle'
					    })
					break
				}
			},
			action(e,data=null){
				this.visible[e] = true
				switch(e){
					case 'add':
					    this.form[e] = {
					    	Id:null,
							UseCoupon: 0,
							Cash: 0,
					    	Title: null,
					    	Weight: null,
					    	Price: null,
							Gift: null,
							Cut: null,
					    	Foods_Choose_Id: 0,
					    	Foods_Shop_Cut_Id: 0,
							Season: 0,
					    	Describe: null,
					    	Image_Url: null,
					    	Image: []
					    }
					    if(data){
					    	this.form[e].Id = data.Id
					    	this.form[e].UseCoupon = data.UseCoupon
					    	this.form[e].Cash = data.Cash
					    	this.form[e].Title = data.Title
							this.form[e].Weight = data.Weight
					    	this.form[e].Price = data.Price / 100
					    	this.form[e].Gift = data.Gift==0 ? null : data.Gift
					    	this.form[e].Cut = data.Cut
					    	this.form[e].Foods_Choose_Id = data.Foods_Choose_Id
					    	this.form[e].Foods_Shop_Cut_Id = data.Foods_Shop_Cut_Id
					    	this.form[e].Season = data.Season
					    	this.form[e].Describe = data.Describe
					    	this.form[e].Image_Url = data.Image_Url
					    	this.form[e].Image = data.Image.split(",")
					    }
					break
					case 'sell':
					    this.form[e] = {Title:null}
						if(data){
							this.his = []
							this.form[e].Title = data.Title
							this.$socket.sendMessage({action: 'ItemHis', menu: this.menuId, id: data.Id, token: this.userInfo.Token},this)
						}
					break
					case 'addcut':
					    this.form[e] = {
					    	Cut: 0,
					    	Title: null
					    }
					break
					case 'addchoose':
					    this.form[e] = {Id: null, Name:null, Tags: null}
					    if(data){
							this.form[e].Id = data.Id
					    	this.form[e].Name = data.Name
							this.form[e].Tags = data.Tags
					    }
					break
				}
			},
			//提交保存
			Foods(){
				this.$socket.sendMessage({action: 'Foods', form: this.form.add, menu: this.menuId, token: this.userInfo.Token},this)
			},
			deleteFoods(id,status){
				if(this.hasLogin){
					this.$socket.sendMessage({action: 'deleteFoods', menu: this.menuId, id: id, status: status, token: this.userInfo.Token},this)
				}
			},
			TimeChange(e){
				this.$set(this.form.add,e.variable,new Date(e.date.f3).getTime() / 1000)
			},
			FoodsCut(){
				this.$socket.sendMessage({action: 'FoodsCut', form: this.form.addcut, menu: this.menuId, token: this.userInfo.Token},this)
			},
			deleteFoodsCut(id){
				this.$socket.sendMessage({action: 'deleteFoodsCut', id: id, menu: this.menuId, token: this.userInfo.Token},this)
			},
			FoodsChoose(){
				this.$socket.sendMessage({action: 'FoodsChoose', form: this.form.addchoose, menu: this.menuId, token: this.userInfo.Token},this)
			},
			deleteFoodsChoose(id){
				this.$socket.sendMessage({action: 'deleteFoodsChoose', id: id, menu: this.menuId, token: this.userInfo.Token},this)
			},
			
		}
	}
</script>

<style lang="scss">
	.content{
		overflow: hidden;
		width: calc(100% - 40px);
		height: calc(100% - 30px);
		padding: 10px;
		margin: 0 10px 10px;
		background: #fff;
		&-popop{
			overflow: hidden;
			&-list{
				margin-right: 10px;
			}
			&-button{
				width: 150px;
			}
			&-title{
				margin-bottom: 20px;
			}
			&-line{
				display: grid;
				grid-template-columns: 15% 85%;
				margin: 15px 0;
				line-height: 35px;
				width: 100%;
				overflow: hidden;
				&-name{
					overflow: hidden;
				}
				&-content{
					padding: 0 5px 2px 0;
					text-align: center;
				}
			}
		}
		&-action{
			overflow: hidden;
			height: 40rpx;
			> *{
				margin-right: 10rpx;
			}
		}
		&-box{
			height: calc(100% - 40rpx);
			overflow: hidden;
			&-action{
				color: #4165d7;
				margin-right: 10px;
				cursor: pointer;
			}
		}
	}
</style>