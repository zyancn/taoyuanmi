import Vue from 'vue'
import {mapState , mapMutations} from 'vuex'
import store from './store'
import App from './App'
import Md5 from './static/js/md5'
import Filter from './Filter'
import { getLodop } from './Print'

for (let key in Filter){
  Vue.filter(key,Filter[key])
}

Vue.config.productionTip = false

const sendMessage = (data,context=null)=>{
	if(store.state.server.socket){
		uni.sendSocketMessage({
		    data: JSON.stringify(data)
		})
	}
}

Vue.prototype.$store = store
Vue.prototype.$socket = {sendMessage}
Vue.prototype.colorList = ['#F56C6C', '#fab040', '#21c26c']
Vue.prototype.uploadImage = function(file){
	return new Promise((url,reject)=>{
		const name = Md5.hexMD5(file)
		const now = new Date();
		const month = now.getMonth() + 1
		const filename = 'taoyuanmi/' + now.getFullYear() + '/' + month + '/' + now.getDate() + '/' + name
		store.state.server.coskey.key.postObject({
		    Bucket: 'taoyuanmi-1302600747',
		    Region: 'ap-shanghai',
		    Key: filename,
		    FilePath: file
		}, function (err, data) {
		    if (err == null) {
				url(store.state.server.coskey.url + filename)
		    }else{
				url(null)
			}
		})
	})
}
//methods版STATE参数赋值
Vue.prototype.setState = function(db,table,value){
	store.state[db][table] = value
}
//template版STATE参数赋值
Vue.prototype.stateChange = function(e,db,table){
	store.state[db][table] = e.detail.value
}
//获取打印机名称
Vue.prototype.getPrinter = function(machine){
	try{ 
		LODOP = getCLodop()
		return LODOP.GET_PRINTER_NAME(machine)
	} catch(err) {
		return '正在初始化'
	};
}
//CUT为打印数据类型 0 订单
//DATA为对应的数据类型的数据
//MODE为打印模式 0 预览 1打印 2维护 3设计
Vue.prototype.print = function(cut,data,mode){
	var top = 10
	var pay = ['未支付','微信支付','支付宝']
	LODOP = getLodop()
	switch(cut){
		case 0:
		    //样式
		    LODOP.PRINT_INIT('订单#' + data.Id) 
		    LODOP.SET_PRINT_STYLE('FontName', '微软雅黑') 
		    //打印标题
		    LODOP.SET_PRINT_STYLE('FontSize', 22) 
		    LODOP.SET_PRINT_STYLE('Bold', 1)
		    LODOP.SET_PRINT_STYLE('Alignment', 2)
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", '#' + data.Id + '# 小票') 
		    //分界线
		    top += 10
		    LODOP.ADD_PRINT_LINE(top + 'mm',0, top + 'mm', "480mm",1, 1)
		    //打印订单来源店铺
		    top += 15
		    LODOP.SET_PRINT_STYLE('FontSize', 14) 
		    LODOP.SET_PRINT_STYLE('Bold', 0)
		    LODOP.SET_PRINT_STYLE('Alignment', 2)
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", '陶渊米™'+ data.Store_Id + data.Store_Name)
		    //打印支付方式
		    top += 10
		    LODOP.SET_PRINT_STYLE('FontSize', 18)
		    LODOP.SET_PRINT_STYLE('Bold', 1)
		    LODOP.SET_PRINT_STYLE('Alignment', 2)
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", "----- " + pay[data.Pay_Cut] + " -----")
		    //打印菜品列表
		    top += 5
		    if(data.Foods){
		    	data.Foods.forEach((item,index)=>{
		    		top += 10
		    		LODOP.SET_PRINT_STYLE('FontSize', 14)
		    		LODOP.SET_PRINT_STYLE('Bold', 0)
		    		LODOP.SET_PRINT_STYLE('Alignment', 1)
		    		LODOP.ADD_PRINT_TEXTA(index,top + 'mm', 0, "100%", "10mm", item.Count + "份 * " + item.Title + "[" + item.Choose + "]")
		    	})
		    }
		    //用餐人数
		    top += 20
		    LODOP.SET_PRINT_STYLE('FontSize', 14)
		    LODOP.SET_PRINT_STYLE('Bold', 1)
		    LODOP.SET_PRINT_STYLE('Alignment', 1)
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", '用餐人数：' + data.Dinner_Amount + '人')
		    //下单时间
		    top += 10
		    LODOP.SET_PRINT_STYLE('FontSize', 14)
		    LODOP.SET_PRINT_STYLE('Bold', 0)
		    LODOP.SET_PRINT_STYLE('Alignment', 1)
		    var forDate = Vue.filter('forDate');
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", 1, forDate(data.Create_Time,true))
		    //分界线
		    top += 10
		    LODOP.ADD_PRINT_LINE(top + 'mm',0, top + 'mm', "480mm",1, 1)
		    //实收金额
		    top += 10
		    LODOP.SET_PRINT_STYLE('FontSize', 22)
		    LODOP.SET_PRINT_STYLE('Bold', 1)
		    LODOP.SET_PRINT_STYLE('Alignment', 3)
		    var toMoney = Vue.filter('toMoney');
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", '￥' + toMoney(data.Price,2))
		    //地址
		    top += 15
		    LODOP.SET_PRINT_STYLE('FontSize', 14)
		    LODOP.SET_PRINT_STYLE('Bold', 1)
		    LODOP.SET_PRINT_STYLE('Alignment', 3)
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", data.Address)
		    //联系方式
		    top += 15
		    LODOP.SET_PRINT_STYLE('FontSize', 14)
		    LODOP.SET_PRINT_STYLE('Bold', 1)
		    LODOP.SET_PRINT_STYLE('Alignment', 3)
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", data.Name + ' ' + data.Phone)
		    // 打印红包码
		    top += 15
		    LODOP.ADD_PRINT_BARCODE(top + 'mm',"20mm","48mm","48mm","QRCode","傻不傻？你居然真的扫码！");
		    top += 48
		    LODOP.SET_PRINT_STYLE('FontSize', 14) 
		    LODOP.SET_PRINT_STYLE('Bold', 0)
		    LODOP.SET_PRINT_STYLE('Alignment', 2)
		    LODOP.ADD_PRINT_TEXT(top + 'mm', 0, "100%", "10mm", '小程序扫码领红包')
		    //设置纸张信息
		    LODOP.SET_PRINT_PAGESIZE(0, 480, top * 7, '') 
		    LODOP.SET_PRINT_MODE('PRINT_PAGE_PERCENT', '60%')
		    LODOP.SET_PREVIEW_WINDOW(2, 2, 0, 0, 0, '')
		    //打印网址
		    //LODOP.ADD_PRINT_URL(222,2000,2000,233,"https://blog.csdn.net/qq_43652509");
		    //打印图片
		    //LODOP.ADD_PRINT_IMAGE(100,100,400,400,"<img border='0' src='http://s1.sinaimg.cn/middle/4fe4ba17hb5afe2caa990&690' width='345' height='250'>");
		    //LODOP.ADD_PRINT_HTM(88, 20, 2000, 2000, body) //增加超文本项
		break
	}
	switch(mode){
		case 0:
		    LODOP.PREVIEW() //打印预览
		break
		case 1:
		    LODOP.PRINT() //直接打印
		break
		case 2:
		    LODOP.PRINT_SETUP() //打印维护
		break
		case 3:
		    LODOP.PRINT_DESIGN() //打印设计
		break
	}
}

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
