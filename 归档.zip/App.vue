<script>
	import {mapState,mapMutations} from 'vuex'
	if(window.innerWidth > 750){
	    window.innerWidth = 750;  
	}  
	export default {
		computed: {
			...mapState(['hasLogin','userInfo','server','store']),
		},
		methods: {
			...mapMutations(['login','logout','setInfo','socketStatus','socketClose','setMenu','setRole','setStore']),
			connectSocket(){
				var that = this
				uni.connectSocket({
					url: that.server.url,
					header: {'content-type': 'application/json'},
					success(){
						console.log('开始连接服务器')
					}
				})
			}
		},
		globalData: {
			context: null
		}, 
		onLaunch: function() {
			const that = this
			//连接服务器
			that.connectSocket()
			//连接断开
			uni.onSocketClose(function (res) {
				that.socketStatus(false)
				setTimeout(function(){
					that.connectSocket()
				},2000)
			})
			//连接错误
			uni.onSocketError(function (res) {
				that.socketStatus(false)
				setTimeout(function(){
					that.connectSocket()
				},2000)
			})
			//连接成功
			uni.onSocketOpen(function (res) {
				uni.hideLoading()
				that.socketStatus(true)
				var data = uni.getStorageSync('Login')
				if(data){
					that.$socket.sendMessage({action: 'ReLogin', userinfo: data})
				}
			})
			//数据到达路由接口
			uni.onSocketMessage(function (data) {
			    var res = JSON.parse(data.data)
				var pages = getCurrentPages()
				var refs = pages[pages.length - 1].$vm.$refs
			    switch (res.action) {
					//获取门店
					case 'GetMyStore':
					    that.setStore(res.data)
					break
					//新订单播放声音
					case 'neworder':
					    if(that.store.choose == res.data.Store_Id){
							refs.component[refs.component.length - 1].onMessage(res)
							const innerAudioContext = uni.createInnerAudioContext();
							innerAudioContext.autoplay = true;
							innerAudioContext.volume = that.store.Sound / 100;
							innerAudioContext.src = 'https://shanghai.image.taoyuanmi.com/sound/order.wav';
							innerAudioContext.onEnded(() => {
								if(that.store.autoSell){
									const player = uni.createInnerAudioContext();
									player.autoplay = true;
									player.src = 'https://shanghai.image.taoyuanmi.com/sound/auto.wav';
									player.volume = that.store.Sound / 100;
									player.onPlay(() => {
										if(that.store.autoSell){
											//自动接单
											that.$socket.sendMessage({action: 'orderAction', store: that.store.choose, menu: 46, cut: 1, order: res.data.Id, token: that.userInfo.Token})
										}
									});
								}
							});
						}
					break
					//通用MSG提示
			        case 'msg':
					    refs.message.open({
					        message: res.data,
					    	type: 'warn'
					    })
			        break
					//通用MSG提示
					case 'success':
					    refs.message.open({
					        message: res.data,
					    	type: 'success_no_circle'
					    })
					break
					//通用提示框
					case 'modal':
					    uni.showModal({
					        title: res.data.title,
					        content: res.data.content,
					    	confirmText: res.data.confirmText
					    })
					break
					//退出登录
				    case 'LoginOut':
						that.logout()
				    break
					//登录
					case 'Login':
						const user = that.userInfo
						that.login(res.data.token)
						user.Id = res.data.user.Id
						user.Name = res.data.user.Name
						user.UserName = res.data.user.UserName
						that.setInfo(user)
						that.$socket.sendMessage({action: 'GetMenu', token: res.data.token})
						that.$socket.sendMessage({action: 'GetRole', token: res.data.token})
						var Storage = {Id:res.data.user.Id,Token: res.data.token, UserName: res.data.user.UserName, Name: res.data.user.Name}
						uni.setStorage({
							key: 'Login',  
							data: Storage
						})
						that.$socket.sendMessage({action: 'GetMyStore', token: res.data.token})
						if(that.$route.path == '/' || that.$route.path == '/pages/login/login'){
							refs.message.open({
							    message: "登录成功",
								type: 'success_no_circle'
							})
							setTimeout(()=>{
								uni.redirectTo({
								    url: '/pages/admin/admin'
								})
							}, 1500);
						}
					break
					//获取菜单
					case 'GetMenu':
						that.setMenu(res.data)
					break
					//获取角色
					case 'GetRole':
						that.setRole(res.data)
					break
					//获取CosKey
					case 'GetCosKey':
					    let session = res.data.key
					    const COS = require('./static/js/cos-wx-sdk-v5.js')
						that.$set(that.server.coskey,'time',res.data.time)
						that.$set(that.server.coskey,'key',new COS({
					        getAuthorization: function (options, callback) {
					            callback({
					                TmpSecretId: session.credentials.tmpSecretId,
					                TmpSecretKey: session.credentials.tmpSecretKey,
					                XCosSecurityToken: session.credentials.sessionToken,
					                ExpiredTime: session.expiredTime,
					            })
					        }
					    }))
					break
			        default:
						refs.component[refs.component.length - 1].onMessage(res)
			        break
			    }
			})
			
		}
	}
</script>

<style lang="scss">
	page{
		font-size: 13rpx;
		font-family: "微软雅黑", Arial, Helvetica, sans-serif;
	}
	::-webkit-scrollbar{
		width:3rpx;
		height:3rpx;
	}
	::-webkit-scrollbar-thumb{
		background-color:rgba(144,147,153,0.2);
	}
	::-webkit-scrollbar-track{
		background:transparent;
	}
	uni-button[disabled][type=primary] {
		background-color: #808080;
	}
	uni-swiper-item{
		cursor: default;
	}
	uni-slider {
		min-width: 150rpx;
	    margin: 0;
	    padding: 0;
	    display: block;
	}
	uni-picker {
		position: initial;
	    display: block;
	    cursor: pointer;
	}
</style>
