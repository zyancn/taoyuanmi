import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		hasLogin: false,
		server:{
			url: 'wss://wm.wss.taoyuanmi.com:99',
			socket: false,
			coskey: {key:null , time:0, url: "https://shanghai.image.taoyuanmi.com/"}
		},
		userInfo: {
			Id:0,
			Token:null,
			Name:null,
			UserName:null
		},
		menu: [],
		role: [],
		store: {choose: null , data: [], autoSell: true, Sound: 100}
	},
	mutations: {
		login(state,token = null){
			if(token){
				state.hasLogin = true;
				state.userInfo.Token = token;
			}else{
				state.hasLogin = false;
			}
		},
		logout(state){
			state.hasLogin = false;
			state.userInfo.Token = null;
			uni.removeStorage({
			    key: 'Login'  
			})
		},
		socketStatus(state,status=null){
			state.server.socket = status == null ? !state.server.socket : status
		},
		setInfo(state,userInfo){
			state.userInfo = userInfo
		},
		setMenu(state,menu){
			state.menu = menu
		},
		setRole(state,role){
			state.role = role
		},
		setStore(state,store){
			if(store.length > 0){
				state.store.data = store
				state.store.choose = store[0].Id
			}
		},
		setStoreChoose(state,choose){
			state.store.choose = choose
		}
	},
	actions: {
	
	}
})

export default store