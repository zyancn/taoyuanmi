<template>
	<view class="admin">
		<cl-dialog title="网络问题" :visible.sync="!server.socket" width="350px">
		    <text>您已经断开了与服务器的连接，请重新连接！</text>
			<view slot="footer" class="admin-dialog">
			  <cl-button type="default">关闭页面</cl-button>
			  <cl-button type="primary" @click="handleSave">重新连接</cl-button>
			</view>
		</cl-dialog>
		<cl-message ref="message"></cl-message>
		<scroll-view scroll-y class="admin-menu">
			<image src="../../static/admin.png" mode="aspectFill" class="admin-menu-logo"></image>
			<block v-for="item in getRootMenu" :key="item.Id">
				<block v-if="item.child.length > 0">
					<view class="admin-menu-list" @click="open(item)">
						<view class="admin-menu-list-icon">
							<cl-image v-if="item.Icon" :src="item.Icon" :size="20"></cl-image>
							<cl-icon v-else name="cl-icon-link" :size="20"></cl-icon>
						</view>
						<text>{{item.Name}}</text>
						<view class="admin-menu-list-arrow">
							<cl-icon :name="item.Open ? 'cl-icon-arrow-bottom' : 'cl-icon-arrow-right'" :size="12"></cl-icon>
						</view>
					</view>
					<block v-if="item.Open" v-for="child in item.child" :key="child.Id">
						<view @click="menuChange(child)" class="admin-menu-detail" :class="{'active' : tab[CurrentIndex].Id == child.Id}">
							<text>{{child.Name}}</text> 
						</view>
					</block>
				</block>
			</block>
		</scroll-view>
		<view class="admin-scroll">
			<view class="admin-scroll-head">
				<view class="admin-scroll-head-box">
					<cl-icon name="cl-icon-type" :size="20"></cl-icon>
					<text>商家系统</text>
					<cl-icon name="cl-icon-arrow-right" :size="15"></cl-icon>
					<text>{{tab[CurrentIndex].Name}}</text>
				</view>
				<view class="admin-scroll-head-box">
					<cl-select placeholder="切换门店" :value="store.choose" :unborder="true" :options="getStore" @change="setState('store','choose',$event)"></cl-select>
					<cl-icon name="cl-icon-notification" :size="20"></cl-icon>
					<cl-slider :value="store.Sound" :min="0" :max="100" :step="1" show-value @change="stateChange($event,'store','Sound')"></cl-slider>
					<cl-checkbox :value="store.autoSell" label="true" @change="setState('store','autoSell',$event)">自动接单/打印</cl-checkbox>
					<view>
						<cl-icon class="cl-icon-dayinji cl-icon-right" :size="16"></cl-icon>
						<text>打印机（{{getPrinter(-1)}}）</text>
					</view>
					<view>
						<cl-icon class="cl-icon-me cl-icon-right" :size="16"></cl-icon>
						<text>{{userInfo.Name}}</text>
					</view>
				</view>
			</view>
			<view class="admin-scroll-open">
				<block v-for="(item,index) in tab" :key="index">
					<view class="admin-scroll-open-list">
						<view class="admin-scroll-open-list-button" :class="{'admin-scroll-open-list-current':CurrentIndex == index}">
							<text @click="menuChange(item)">{{item.Name}}</text>
							<span @click="menuDelete(item)">
								<cl-icon class="admin-scroll-open-list-button-del" name="cl-icon-close" :size="14" v-if="CurrentIndex == index && index > 0"></cl-icon>
							</span>
						</view>
					</view>
				</block>
			</view>
			<swiper :current='CurrentIndex' disable-touch duration="600" class="admin-scroll-swiper">
				<block v-for="(item,index) in tab" :key="index">
					<swiper-item>
						<scroll-view scroll-y class="admin-scroll-swiper-view">
							<keep-alive>
							  <component :is="item.Page" :menuId="item.Id" ref="component"></component>
							</keep-alive>
						</scroll-view>
					</swiper-item>
				</block>
			</swiper>
		</view>
	</view>
</template>

<script>
	import {mapState,mapMutations} from 'vuex'
	import Index from '@/components/Index'
	import Admin from '@/components/Admin'
	import AdminMenu from '@/components/AdminMenu'
	import AdminSet from '@/components/AdminSet'
	import AdminUser from '@/components/AdminUser'
	import AdminItem from '@/components/AdminItem'
	import AdminFoods from '@/components/AdminFoods'
	import StoreOpen from '@/components/StoreOpen'
	import StoreFoods from '@/components/StoreFoods'
	import StoreStyle from '@/components/StoreStyle'
	import StoreOrder from '@/components/StoreOrder'
	export default{
		components: {
			Index,Admin,AdminMenu,AdminSet,AdminUser,AdminItem,AdminFoods,StoreOpen,StoreFoods,StoreStyle,StoreOrder
		},
		data(){
			return{
				CurrentIndex: 0,
				tab:[
					{Id: 0,Name : '首页', Page: 'Index'}
				]
			}
		},
		computed: {
			...mapState(['hasLogin','server','userInfo','menu','store']),
			//获取根菜单 并同步子菜单
			getRootMenu(){
				let root = this.menu.filter(menu=>menu.Cut===0)
				root.forEach(item=>{
					item.child = this.menu.filter(menu=>menu.Cut===item.Id)
				})
				return root
			},
			getStore(){
				let store = []
				this.store.data.forEach(item=>{
					store.push({label: item.Id + '-' +item.Name, value: item.Id})
				})
				return store
			},
		},
		watch:{
			hasLogin(newData,oldData){
				if(!newData){
					uni.navigateTo({
						url: '/pages/login/login'
					})
				}
			}
		},
		onShow() {
			let store = uni.getStorageSync('Login')
			if(!this.hasLogin && !store){
				uni.navigateTo({
					url: '/pages/login/login'
				})
			}
		},
		onLoad() {
			
		},
		methods:{
			currentTabComponent(e){
				console.log(e)
			},
			open(item){
				let index = this.menu.findIndex(menu=>menu.Id === item.Id)
				this.$set(this.menu[index],'Open',!this.menu[index].Open)
			},
			menuDelete(e){
				let index = this.tab.findIndex(tab=>tab.Page == e.Page)
				this.tab.splice(index,1)
				this.CurrentIndex = index - 1
			},
			menuChange(e){
				let index = this.tab.findIndex(tab=>tab.Page == e.Page)
				if(index == -1){
					let tmp = {Id: e.Id, Name : e.Name, Page: e.Page}
					this.tab.push(tmp)
					this.CurrentIndex = this.tab.length - 1
				}else{
					this.CurrentIndex = index
				}
			}
		}
	}
</script>

<style lang="scss">
	.admin{
		display: flex;
		flex-direction: row;
		overflow: hidden;
		&-dialog{
			width: 100%;
			overflow: hidden;
			> *{
				margin-left: 10rpx;
			}
		}
		&-menu{
			height: 100vh;
			display: flex;
			flex-direction: column;
			width: 300px;
			background-color: #2f3447;
			box-shadow: 0 4px 8px rgba(0,0,0,.3);
			overflow: hidden;
			&-logo{
				width: calc(100% - 40px);
				height: 50px;
				padding: 20px;
				overflow: hidden;
			}
			&-list{
				height: 50px;
				padding: 0 20px;
				display: flex;
				flex-direction: row;
				color: rgba(255,255,255,.7);
				align-items: center;
				overflow: hidden;
				&-icon{
					margin: 0 15px 0 5px;
					position: relative;
					top: 1px;
				}
				&-arrow{
					margin-left: auto;
				}
			}
			&-detail{
				padding: 0 20px 0 80px;
				height: 50px;
				display: flex;
				flex-direction: row;
				align-items: center;
				cursor: pointer;
				color: rgba(255,255,255,.7);
				transition:all 0.5s ease-out;
				background-color: rgba(0,0,0,.2);
				overflow: hidden;
				&:hover{
					background-color: #666;
					color: #fff;
				}
				&.active{
					background-color: #111;
					color: #fff;
				}
			}
		}
		&-scroll{
			background-color: #f7f7f7;
			width: 100%;
			height: 100%;
			overflow: hidden;
			&-head{
				display: flex;
				overflow: hidden;
				width: calc(100% - 40rpx);
				padding: 0 20rpx;
				background-color: #FFFFFF;
				height: 50rpx;
				line-height: 28rpx;
				align-items: center;
				justify-content: space-between;
				&-box{
					overflow: hidden;
					margin-right: 15rpx;
					display: flex;
					> *{
						margin-right: 20rpx;
					}
				}
			}
			&-open{
				display: flex;
				height: 50px;
				align-items: center;
				overflow: hidden;
				&-list{
					margin-left: 10px;
					&-button{
						background-color: #FFFFFF;
						text-align: center;
						padding: 6px 10px;
						color: #666;
						border-radius: 5px;
						&-del{
							margin-left: 5px;
							&:hover{
								background-color: #ccc;
							}
						}
					}
					&-current{
						color: #000;
					}
				}
			}
			&-swiper{
				width: 100%;
				height: calc(100vh - 100px);
				display: flex;
				justify-content: center;
				align-items: center;
				&-view{
					height: 100%;
				}
			}
		}
	}
</style>
