<template>
	<view class="login">
		<cl-message ref="message"/>
		<view class="login-head">
			<view class="login-head-font login-head-title">轻松开店 科技护航</view>
			<view class="login-head-font login-head-content">灵活营销、深度分析，助力加盟商生意兴隆</view>
		</view>
		<view class="login-main">
			<view class="login-main-box">
				<view>商家登录</view>
				<view class="login-main-box-line"><cl-input :border="false" prefix-icon='cl-icon-me' v-model="user" type="number" maxlength="11" placeholder="TYMID/手机号码"></cl-input></view>
				<view class="login-main-box-line"><cl-input :border="false" prefix-icon='cl-icon-mima' v-model="password" type="password" maxlength="32" placeholder="登录密码"></cl-input></view>
				<view class="login-main-box-line"><cl-button type="primary" @click="bindLogin()" style="width: 100%;" :loading="!server.socket">{{server.socket ? '登录':'正在连接陶渊米中心'}}</cl-button></view>
				<view class="login-main-box-right"><cl-tag class="cl-icon-tel" plain>加盟电话：0579-85340787</cl-tag></view>
			</view>
		</view>
		<view class="login-foot">
			<view class="login-foot-copy">©2020 taoyuanmi.com 浙ICP备20027881号-1 义乌市桑榆非渔餐饮管理有限公司</view>
		</view>
	</view>
</template>

<script>
	import {mapState,mapMutations} from 'vuex'
	export default {
		computed: {
			...mapState(['hasLogin','server']),
		},
		onShow() {
			if(this.hasLogin){
				uni.redirectTo({
				    url: '/pages/admin/admin'
				})
			}
		},
		data() {
			return {
				user:'',
				password:'',
				loading: false
			};
		},
		methods: {
		    bindLogin() {
				//正则
				if (!(/^1\d{10}$/.test(this.user))) {
					this.$refs["message"].open({
					    message: "商家号/工号格式错误",
						type: "warn"
					})
				    return;
				}
				if(!this.password){
					this.$refs["message"].open({
					    message: "请输入密码",
						type: "warn"
					})
					return;
				}
				if(this.server.socket){
					this.$socket.sendMessage({action: 'Login', user: this.user, password: this.password})
				}else{
					this.$refs["message"].open({
					    message: "未连接服务器",
						type: "warn"
					})
				}
		    }
		}
	}
</script>

<style lang="scss">
	page{
		height: 100vh;
		width: 100%;
		background: url("https://shanghai.image.taoyuanmi.com/css/admin/login/tym.jpg") no-repeat;
		background-size: 100% 100%;
	}
	.login{
		height: 100%;
		width: 100%;
		font-size: 14rpx;
		&-head{
			overflow: hidden;
			text-align: center;
			width: 100%;
			height: 100rpx;
			padding: 50rpx 0;
			text-shadow: 1px 1px 5px #333;
			&-font{
				color: #fff;
				line-height: 50rpx;
			}
			&-title{
				font-size: 50rpx;
				font-weight: bold;
			}
			&-content{
				font-size: 25rpx;
			}
		}
		&-main{
			overflow: hidden;
			width: 100%;
			height: calc(100% - 300rpx);
			&-box{
				padding: 20rpx 30rpx;
				overflow: hidden;
				width: 400rpx;
				background: #fff;
				border-radius: 5rpx;
				margin: 50rpx auto 0;
				> *{
					width: 100%;
					padding: 15rpx 0;
				}
				&-line{
					border-bottom: 1rpx solid #f1f1f1;
				}
				&-right{
					display: flex;
					justify-content: flex-end;
				}
			}
		}
		&-foot{
			overflow: hidden;
			width: 100%;
			height: 100rpx;
			&-copy{
				text-align: center;
				color: #fff;
				line-height: 100rpx;
			}
		}
	}
</style>
