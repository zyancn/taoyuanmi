<template>
	<view class="cl-grid" :class="[{'cl-grid--border': border}]" :style="{ border }">
		<slot></slot>
	</view>
</template>

<script>
import Emitter from "../../mixins/emitter";
export default {
	componentName: "ClGrid",
	props: {
		border: Boolean
	},
	mixins: [Emitter]
};
</script>