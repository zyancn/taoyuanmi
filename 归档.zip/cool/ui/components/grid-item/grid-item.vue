<template>
	<view class="cl-grid-item" :class="[{'cl-grid-item--center': center,'cl-grid-item--isTitle': isTitle}]" :style="{ width }" @tap="onTap">
		<slot></slot>
	</view>
</template>

<script>
import { getParent } from "../../utils";
import Emitter from "../../mixins/emitter";

export default {
	componentName: "ClGridItem",
	props: {
		index: [Number, String],
		width: String,
		center: Boolean,
		isTitle: {
			type: Boolean,
			default: false
		}
	},
	mixins: [Emitter],
	computed: {
		parent() {
			return getParent.call(this, "ClGrid", ["border"]);
		}
	},
	methods: {
		onTap() {
			this.dispatch("ClGrid", "grid.tap", this.index);
		}
	}
};
</script>