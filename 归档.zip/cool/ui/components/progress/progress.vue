<template>
	<view class="cl-progress">
		<view class="cl-progress-bar" v-if="type === 'line'">
			<view class="cl-progress-bar__outer" :style="{ height }">
				<view
					class="cl-progress-bar__inner"
					:style="{
						backgroundColor,
						width
					}"
				></view>
			</view>
		</view>
		<slot name="text">
			<view class="cl-progress__text" v-if="showText">
				<template v-if="!status">{{stock}}</template>
				<text class="cl-progress__icon" v-else :class="icon"></text>
			</view>
		</slot>
	</view>
</template>

<script>
import { getCurrentColor } from '../../utils';

export default {
	name: 'ClProgress',
	props: {
		type: {
			type: String,
			default: 'line'
		},
		ready: {
			type: [String, Number],
			default: 0
		},
		stock: {
			type: [String, Number],
			default: 0
		},
		strokeWidth: {
			type: Number,
			default: 12
		},
		showText: {
			type: Boolean,
			default: true
		},
		color: {
			type: [String, Array],
			default: ''
		},
		status: {
			type: Boolean
		},
		icon: String
	},
	computed: {
		progress(){
			return this.stock ? Math.ceil(this.stock / this.ready * 100) : 100
		},
		height() {
			return this.strokeWidth + 'px';
		},
		width() {
			return (
				(() => {
					if (this.progress > 100) {
						return 100;
					} else if (this.progress < 0) {
						return 0;
					} else {
						return this.progress;
					}
				})() + '%'
			);
		},
		backgroundColor() {
			return getCurrentColor({
				value: this.progress,
				color: this.color,
				max: 100
			});
		}
	}
};
</script>
