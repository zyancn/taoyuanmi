const Filters = {
    //转化为保留小数点后两位的数值
    toMoney(value,fix=2) {
    	let res = value / 100
        return res.toFixed(fix);
    },
    //获取两个坐标点的物理距离 参数 起点纬度 起点经度 目标纬度目标经度
    getDistance(lng1, lat1, lng2, lat2){ 
    	lng1 = lng1 == null ? '0.0000' : lng1
    	lng2 = lng2 == null ? '0.0000' : lng2
    	lat1 = lat1 == null ? '0.0000' : lat1
    	lat2 = lat2 == null ? '0.0000' : lat2
    	lat1 = lat1 * Math.PI / 180;
    	lng1 = lng1 * Math.PI / 180;
    	lat2 = lat2 * Math.PI / 180;
    	lng2 = lng2 * Math.PI / 180;
    	let earthRadius = 6378137;
    	let calcLongitude = lng2 - lng1;
    	let calcLatitude = lat2 - lat1;  
    	let stepOne = Math.pow(Math.sin(calcLatitude / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(calcLongitude / 2), 2);  
    	let stepTwo = 2 * Math.asin(Math.min(1, Math.sqrt(stepOne))); 
    	let calculatedDistance = earthRadius * stepTwo;   
    	return Math.round(calculatedDistance);   
    },
    //距离m转km
    distance(distance){
    	let res = distance > 1000 ? distance / 1000 : distance
    	let dan = distance > 1000 ? 'km' : 'm'
    	return res.toFixed(2)+dan;
    },
	//时间戳转时间
	forDate(time,cut=null){
		let date = new Date(time * 1000)
		let Y = date.getFullYear()+'-'
		let M = date.getMonth()+1+'-'
		let D = date.getDate()
		let h = ' ' + date.getHours() + ':'
		let m = date.getMinutes()
		return cut ? Y + M + D + h + m  : Y + M + D
    },
	//取数组平均数
	getAverage(content){
		let array = content.split(",")
		let sum = 0
		array.forEach(item=>{
			sum = sum + item / 1
		})
		return Math.floor(sum / array.length)
	},
	numText(num){
		var textArr = [ 
              {name:0,value:'十'},            
              {name:1,value:'一'},
              {name:2,value:'二'},
              {name:3,value:'三'},
              {name:4,value:'四'},
              {name:5,value:'五'},
              {name:6,value:'六'},
              {name:7,value:'七'},
              {name:8,value:'八'},
              {name:9,value:'九'}]
	    var numArr = num.toString().split('');
	    var that = this;            
	    var result  = []; 
	    numArr.forEach(res=>{
	        textArr.forEach(item=>{                 
	            if(item.name==res){ result.push(item.value) }  
	        })
	    })
	    return '款式' + result.join('');
	},
	getStatus(status){
		let can = {
			'0': "等待付款",
			'100': "等待接单",
			'101': "门店拒绝接单",
			'102': "门店接单超时",
			'200': "门店已接单",
			'201': "正在烹饪",
			'202': "正在打包",
			'300': "等待配送",
			'301': "等待取餐",
			'302': "正在配送到您手中",
			'400': "等待评价", 
			'500': "正在售后申诉",
			'501': "申诉处理结束",
			'502': "申诉处理超时",
			'600': "付款超时",
			'601': "已退款",
			'602': "退款处理中",
			'700': "完成",
			'800': "已撤销",
			'900': "已删除",
		}
		return can[status]
	},
	getSeason(v){
		let k = ['全年','春季','夏季','秋季','冬季']
		return k[v]
	}
}

export default Filters;